<?php
require 'connection.php'; 


if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}


$totalAppointments = $conn->query("SELECT COUNT(*) as count FROM appointment")->fetch_assoc()['count'];
$totalCustomers = $conn->query("SELECT COUNT(DISTINCT email) as count FROM appointment")->fetch_assoc()['count'];
$totalAccepted = $conn->query("SELECT COUNT(*) as count FROM appointment WHERE status = 'Accepted'")->fetch_assoc()['count'];
$totalRejected = $conn->query("SELECT COUNT(*) as count FROM appointment WHERE status = 'Rejected'")->fetch_assoc()['count'];
$totalPending = $conn->query("SELECT COUNT(*) as count FROM appointment WHERE status = 'Pending'")->fetch_assoc()['count'];
$totalServices = $conn->query("SELECT COUNT(*) as count FROM services")->fetch_assoc()['count'];

$todaySalesQuery = "
    SELECT SUM(services.cost) as total 
    FROM invoice 
    JOIN services ON invoice.service_id = services.service_id 
    WHERE DATE(invoice.posting_date) = CURDATE()";
$todaySales = $conn->query($todaySalesQuery)->fetch_assoc()['total'] ?? 0;


$totalSalesQuery = "
    SELECT SUM(services.cost) as total 
    FROM invoice 
    JOIN services ON invoice.service_id = services.service_id";
$totalSales = $conn->query($totalSalesQuery)->fetch_assoc()['total'] ?? 0;


$salesLast7DaysQuery = "
    SELECT DATE(invoice.posting_date) as date, SUM(services.cost) as total 
    FROM invoice 
    JOIN services ON invoice.service_id = services.service_id 
    WHERE invoice.posting_date >= CURDATE() - INTERVAL 7 DAY 
    GROUP BY DATE(invoice.posting_date)
    ORDER BY DATE(invoice.posting_date) DESC";
$salesLast7DaysResult = $conn->query($salesLast7DaysQuery);

$salesData = [];
while ($row = $salesLast7DaysResult->fetch_assoc()) {
    $salesData[] = $row;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="icon/fontawesome-free-6.7.1-web/css/all.min.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }

        .sidebar {
            height: 100vh;
            background-color: #7e57c2;
            color: #fff;
            padding: 15px;
            position: fixed;
            width: 250px;
        }

        .sidebar h3 {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar a {
            color: #fff;
            text-decoration: none;
            padding: 10px 15px;
            display: block;
            border-radius: 5px;
            margin: 5px 0;
        }

        .sidebar a:hover {
            background-color: #6a4aa0;
        }

        .content {
            margin-left: 270px;
            padding: 20px;
        }

        .header {
            background-color: #7e57c2;
            color: #fff;
            padding: 15px;
            border-radius: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header img {
            height: 50px;
        }

        .card {
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .sales-chart {
            background-color: #f9f6ff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
<div class="sidebar">
        <h3>Admin Panel</h3>
        <a href="admin_dashboard.php"><i class="fas fa-chart-line"></i> Dashboard</a>
        <a href="manage_appointments.php"><i class="fas fa-calendar-alt"></i> Manage Appointments</a>

        <div class="dropdown">
            <button class="btn dropdown-toggle w-100 text-start text-white" id="servicesDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-concierge-bell"></i> Manage Services
            </button>
            <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="servicesDropdown">
                <li><a class="dropdown-item" href="manage_services.php">View Services</a></li>
                <li><a class="dropdown-item" href="add_service.php">Add Service</a></li>
            </ul>
        </div>

        <a href="invoices.php"><i class="fas fa-file-invoice"></i> Manage Invoices</a>
        <a href="notification.php"><i class="fa-solid fa-bell"></i> Notification</a>
        <a href="subscriber.php"><i class="fa-solid fa-user"></i> Subscribers</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <div class="content">
        <div class="header">
            <h2>Welcome, <?php echo htmlspecialchars($_SESSION['admin_username']); ?>!</h2>
            <h2>TIPAWAN SALON</h2>
        </div>
        <div class="row g-4 mt-4">
            <!-- Row 1 -->
            <div class="col-md-3">
                <div class="card p-3 text-center">
                    <h5>Total Appointments</h5>
                    <h3><?php echo $totalAppointments; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 text-center">
                    <h5>Total Customers</h5>
                    <h3><?php echo $totalCustomers; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 text-center">
                    <h5>Total Accepted</h5>
                    <h3><?php echo $totalAccepted; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 text-center">
                    <h5>Total Pending</h5>
                    <h3><?php echo $totalPending; ?></h3>
                </div>
            </div>
        </div>
        <div class="row g-4 mt-2">
            <!-- Row 2 -->
            <div class="col-md-3">
                <div class="card p-3 text-center">
                    <h5>Total Rejected</h5>
                    <h3><?php echo $totalRejected; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 text-center">
                    <h5>Total Services</h5>
                    <h3><?php echo $totalServices; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 text-center">
                    <h5>Today's Sales</h5>
                    <h3>₱<?php echo number_format($todaySales, 2); ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 text-center">
                    <h5>Total Sales</h5>
                    <h3>₱<?php echo number_format($totalSales, 2); ?></h3>
                </div>
            </div>
        </div>
        <div class="row g-4 mt-4">

            <div class="col-md-12">
                <div class="sales-chart">
                    <h4>Last 7 Days Sales</h4>
                    <ul>
                        <?php foreach ($salesData as $sale): ?>
                            <li><?php echo $sale['date']; ?>: ₱<?php echo number_format($sale['total'], 2); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<style>
    /* Sidebar Dropdown Styling */
    .sidebar .dropdown {
        position: relative;
    }

    .sidebar .dropdown-toggle {
        font-size: 16px;
        background: none;
        border: none;
        color: white;
        text-align: left;
        width: 100%;
    }

    .sidebar .dropdown-menu {
        position: absolute;
        left: 0;
        top: 100%;
        background-color: #6a4aa0;
        border: none;
        border-radius: 5px;
        width: 100%;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        z-index: 1000;
    }

    .sidebar .dropdown-menu .dropdown-item {
        color: white;
        padding: 10px 15px;
        font-size: 14px;
        transition: background-color 0.3s ease;
    }

    .sidebar .dropdown-menu .dropdown-item:hover {
        background-color: #5a3c8c;
    }

    .sidebar .dropdown-menu::before {
        content: '';
        position: absolute;
        top: -8px;
        left: 20px;
        border-width: 0 8px 8px 8px;
        border-style: solid;
        border-color: transparent transparent #6a4aa0 transparent;
    }
</style>