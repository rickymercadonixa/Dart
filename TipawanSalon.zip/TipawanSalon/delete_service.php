<?php
require 'connection.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

if (isset($_GET['id'])) {
    $invoice_id = $_GET['id'];

    // Prepare the DELETE query
    $query = "DELETE FROM invoice WHERE invoice_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $invoice_id);

    if ($stmt->execute()) {
        // Redirect with success message
        header("Location: invoices.php?success=Invoice deleted successfully!");
        exit();
    } else {
        // Redirect with error message
        header("Location: invoices.php?error=Failed to delete invoice. Please try again.");
        exit();
    }
} else {
    // Redirect with missing ID error
    header("Location: invoices.php?error=Invoice ID is missing.");
    exit();
}
