<?php
require 'connection.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['sub_id'])) {
    $sub_id = intval($_POST['sub_id']);

    // Prepare and execute the delete query
    $query = "DELETE FROM subscribers WHERE sub_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $sub_id);

    if ($stmt->execute()) {
        // Redirect back to the subscriber list with a success message
        header("Location: subscriber.php?message=Subscriber deleted successfully.");
    } else {
        // Redirect back to the subscriber list with an error message
        header("Location: subscriber.php?message=Failed to delete subscriber.");
    }
    exit();
} else {
    // Redirect back if the request is invalid
    header("Location: subscriber.php");
    exit();
}
?>
