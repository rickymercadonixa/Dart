<?php
require 'connection.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

if (isset($_GET['id'])) {
    $invoice_id = $_GET['id'];

    $query = "DELETE FROM invoice WHERE invoice_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $invoice_id);

    if ($stmt->execute()) {
        header("Location: invoices.php?success=Invoice Deleted Successfully!");
        exit();
    } else {
        echo "Error deleting invoice. Please try again.";
    }
} else {
    echo "Invoice ID is missing.";
    exit();
}
?>
