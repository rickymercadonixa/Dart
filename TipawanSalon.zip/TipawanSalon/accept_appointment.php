<?php
require 'connection.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

if (isset($_GET['id'])) {
    $apt_id = $_GET['id'];

    $query = "UPDATE appointment SET status = 'Accepted' WHERE apt_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $apt_id);

    if ($stmt->execute()) {
        header("Location: manage_appointments.php?success1=1");
    } else {
        header("Location: manage_appointments.php?error1=1");
    }
} else {
    header("Location: manage_appointments.php");
}
?>
