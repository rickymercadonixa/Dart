<?php
require 'connection.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

if (isset($_GET['id'])) {
    $appointmentId = $_GET['id'];

    $conn->begin_transaction();

    try {
        $deleteQuery = "DELETE FROM appointment WHERE apt_id = ?";
        $deleteStmt = $conn->prepare($deleteQuery);
        $deleteStmt->bind_param("i", $appointmentId);

        if (!$deleteStmt->execute()) {
            throw new Exception('Error deleting appointment: ' . $deleteStmt->error);
        }

        $conn->commit();

        header("Location: manage_appointments.php?success=1");
        exit();
    } catch (Exception $e) {
        $conn->rollback();

        header("Location: manage_appointments.php?error=1");
        exit();
    }
} else {
    header("Location: manage_appointments.php");
    exit();
}
?>
