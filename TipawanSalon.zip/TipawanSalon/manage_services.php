<?php
require 'connection.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

$query = "
    SELECT services.service_id, services.ServiceName, services.Cost, services.CreationDate FROM services";
$result = $conn->query($query);

?>

<?php
if (isset($_SESSION['success_message'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success_message']; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['success_message']); ?>
<?php endif; ?>

<?php
if (isset($_SESSION['error_message'])): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error_message']; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['error_message']); ?>
<?php endif; ?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Services</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="icon/fontawesome-free-6.7.1-web/css/all.min.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f8f9fa;
        }

        .sidebar {
            height: 100vh;
            background-color: #7e57c2;
            color: #fff;
            padding: 30px 20px;
            position: fixed;
            width: 250px;
            box-shadow: 4px 0 10px rgba(0, 0, 0, 0.1);
        }

        .sidebar h3 {
            text-align: center;
            margin-bottom: 30px;
            font-weight: bold;
        }

        .sidebar a {
            color: #fff;
            text-decoration: none;
            padding: 10px 15px;
            display: block;
            border-radius: 5px;
            margin: 5px 0;
            transition: background-color 0.3s ease;
        }

        .sidebar a:hover {
            background-color: #6a4aa0;
        }

        .content {
            margin-left: 270px;
            padding: 20px;
        }

        .header {
            background-color: #7e57c2;
            color: #fff;
            padding: 20px;
            border-radius: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .header h2 {
            margin: 0;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f1f1f1;
            font-weight: bold;
            color: #333;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .btn {
            font-size: 14px;
            padding: 8px 12px;
            border-radius: 5px;
        }

        .btn-warning {
            background-color: #ff9800;
            border-color: #ff9800;
        }

        .btn-danger {
            background-color: #f44336;
            border-color: #f44336;
        }

        .btn-warning:hover {
            background-color: #fb8c00;
            border-color: #fb8c00;
        }

        .btn-danger:hover {
            background-color: #e53935;
            border-color: #e53935;
        }

        .table-container {
            overflow-x: auto;
        }
    </style>
</head>
<body>
<div class="sidebar">
        <h3>Admin Panel</h3>
        <a href="admin_dashboard.php"><i class="fas fa-chart-line"></i> Dashboard</a>
        <a href="manage_appointments.php"><i class="fas fa-calendar-alt"></i> Manage Appointments</a>

        <div class="dropdown">
            <button class="btn dropdown-toggle w-100 text-start text-white" id="servicesDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-concierge-bell"></i> Manage Services
            </button>
            <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="servicesDropdown">
                <li><a class="dropdown-item" href="manage_services.php">View Services</a></li>
                <li><a class="dropdown-item" href="add_service.php">Add Service</a></li>
            </ul>
        </div>

        <a href="invoices.php"><i class="fas fa-file-invoice"></i> Manage Invoices</a>
        <a href="notification.php"><i class="fa-solid fa-bell"></i> Notification</a>
        <a href="subscriber.php"><i class="fa-solid fa-user"></i> Subscribers</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <div class="content">
        <div class="header">
            <h2>Manage Services</h2>
        </div>

        <div class="table-container">
            <table class="table table-striped table-bordered text-center">
                <thead>
                    <tr>
                        <th class="text-center">Service #</th>
                        <th class="text-center">Service Name</th>
                        <th class="text-center">Cost</th>
                        <th class="text-center">Creation Date</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td class="text-center"><?php echo $row['service_id'] ?></td>
                                <td class="text-center"><?php echo $row['ServiceName']; ?></td>
                                <td class="text-center">₱<?php echo $row['Cost']; ?></td>
                                <td class="text-center"><?php echo $row['CreationDate']; ?></td>
                                <td class="text-center">
                                    <div class="btn-group" role="group">
                                        <a href="edit_service.php?id=<?php echo $row['service_id']; ?>" class="btn btn-warning btn-sm" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>

                                        <a href="delete_service.php?id=<?php echo $row['service_id']; ?>" class="btn btn-danger btn-sm" title="Delete">
                                            <i class="fas fa-trash-alt"></i>
                                        </a>

                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="10" class="text-center">No Services found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<style>
    /* Sidebar Dropdown Styling */
    .sidebar .dropdown {
        position: relative;
    }

    .sidebar .dropdown-toggle {
        font-size: 16px;
        background: none;
        border: none;
        color: white;
        text-align: left;
        width: 100%;
    }

    .sidebar .dropdown-menu {
        position: absolute;
        left: 0;
        top: 100%;
        background-color: #6a4aa0;
        border: none;
        border-radius: 5px;
        width: 100%;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        z-index: 1000;
    }

    .sidebar .dropdown-menu .dropdown-item {
        color: white;
        padding: 10px 15px;
        font-size: 14px;
        transition: background-color 0.3s ease;
    }

    .sidebar .dropdown-menu .dropdown-item:hover {
        background-color: #5a3c8c;
    }

    .sidebar .dropdown-menu::before {
        content: '';
        position: absolute;
        top: -8px;
        left: 20px;
        border-width: 0 8px 8px 8px;
        border-style: solid;
        border-color: transparent transparent #6a4aa0 transparent;
    }
</style>