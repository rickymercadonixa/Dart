<?php
require 'connection.php';

if (isset($_SESSION['user_id'])) {
  $user_id = $_SESSION['user_id'];
} else {
  header("Location: login.php");
  exit();
}

$service_query = "SELECT * FROM services";
$stmt = $conn->prepare($service_query);
$stmt->execute();
$service_result = $stmt->get_result();

$notifications_query = "SELECT message, created FROM notification WHERE user_id = ? ORDER BY created DESC";
$notifications_stmt = $conn->prepare($notifications_query);
$notifications_stmt->bind_param("i", $user_id);
$notifications_stmt->execute();
$notifications_result = $notifications_stmt->get_result();

$unread_count_query = "SELECT COUNT(*) AS unread_count FROM notification WHERE user_id = ? AND status = 'unread'";
$unread_stmt = $conn->prepare($unread_count_query);
$unread_stmt->bind_param("i", $user_id);
$unread_stmt->execute();
$unread_result = $unread_stmt->get_result();
$unread_count = $unread_result->fetch_assoc()['unread_count'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="icon/fontawesome-free-6.7.1-web/css/all.min.css">
  <title>Tipawan Salon</title>
  <style>
    body {
      margin: 0;
      font-family: 'Arial', sans-serif;
      line-height: 1.6;
    }

    .navbar {
      position: sticky;
      top: 0;
      z-index: 1020;
      background: white;
      transition: background-color 0.3s ease;
    }

    .navbar.scrolled {
      background: rgba(255, 255, 255, 0.9);
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .navbar-brand img {
      max-width: 5rem;
    }

    .hero {
      background-image: url(salon.webp);
      background-size: cover;
      background-position: center;
      position: relative;
      color: white;
      text-align: center;
      padding: 150px 20px;
    }

    .hero::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 0;
    }

    .hero-content {
      position: relative;
      z-index: 1;
    }

    .hero h1 {
      font-size: 3rem;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.8);
    }

    section {
      padding: 60px 20px;
      scroll-margin-top: 80px;
    }

    section.bg-light {
      background-color: #f9f9f9;
    }

    .table {
      border: 1px solid #ddd;
      text-align: left;
      background: #fff;
      margin-top: 20px;
    }

    .table th {
      background: #dfd1ff;
      color: #531eee;
      text-align: center;
    }

    .table td,
    .table th {
      padding: 12px 15px;
    }

    .table tr:nth-child(even) {
      background: #f2f2f2;
    }

    .contact-form {
      max-width: 600px;
      margin: auto;
    }

    @media (max-width: 768px) {
      .hero h1 {
        font-size: 2.5rem;
      }

      .table {
        font-size: 0.9rem;
      }
    }

    #wecando {
      padding: 50px 20px;
      background: #ffffff;
      /* Clean white background */
    }

    #wecando .container {
      max-width: 1200px;
      margin: auto;
      text-align: center;
    }

    #wecando h2 {
      font-size: 2.5rem;
      font-weight: bold;
      color: #6b46c1;
      /* Elegant purple */
      margin-bottom: 30px;
      position: relative;
    }

    #wecando h2::after {
      content: '';
      display: block;
      width: 80px;
      height: 4px;
      background: #9f7aea;
      /* Accent purple */
      margin: 10px auto 0;
      border-radius: 2px;
    }

    #wecando .service {
      margin-bottom: 30px;
      text-align: left;
      padding: 20px;
      border: 1px solid #e0e0e0;
      /* Subtle border for separation */
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s, box-shadow 0.3s;
      background: #fdfdfd;
      /* Slightly off-white for cards */
    }

    #wecando .service:hover {
      transform: scale(1.02);
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
    }

    #wecando .service h3 {
      font-size: 1.5rem;
      color: #4c1d95;
      /* Deep purple for headings */
      margin-bottom: 10px;
    }

    #wecando .service p {
      font-size: 1rem;
      line-height: 1.6;
      color: #444444;
      /* Neutral dark gray for readability */
    }

    #wecando .service p span {
      color: #6b46c1;
      /* Highlighted keywords with purple */
      font-weight: bold;
    }

    @media (max-width: 768px) {
      #wecando h2 {
        font-size: 2rem;
      }

      #wecando .service {
        text-align: center;
      }
    }

    #whychooseus {
      padding: 60px 20px;
      background-color: #ffffff;
      text-align: center;
    }

    #whychooseus h1 {
      font-size: 2.5rem;
      font-weight: bold;
      color: #6b46c1;
      /* Elegant purple for headings */
      margin-bottom: 40px;
      position: relative;
    }

    #whychooseus h1::after {
      content: '';
      display: block;
      width: 100px;
      height: 4px;
      background: #9f7aea;
      /* Purple accent line */
      margin: 10px auto 0;
      border-radius: 2px;
    }

    #whychooseus .row {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 20px;
    }

    #whychooseus .feature {
      background-color: #fdfdfd;
      /* Subtle card background */
      border: 1px solid #e0e0e0;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
      border-radius: 10px;
      padding: 20px;
      max-width: 300px;
      width: 100%;
      transition: transform 0.3s, box-shadow 0.3s;
    }

    #whychooseus .feature:hover {
      transform: scale(1.05);
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
    }

    #whychooseus .feature h2 {
      font-size: 1.5rem;
      font-weight: bold;
      color: #4c1d95;
      /* Dark purple for subheadings */
      margin-bottom: 15px;
    }

    #whychooseus .feature p {
      font-size: 1rem;
      line-height: 1.6;
      color: #444444;
      /* Neutral gray for text */
      margin: 0;
    }

    @media (max-width: 768px) {
      #whychooseus h1 {
        font-size: 2rem;
      }

      #whychooseus .row {
        flex-direction: column;
        align-items: center;
      }
    }

    #whychooseus .feature .icon {
      font-size: 3rem;
      /* Increase emoji size */
      color: #6b46c1;
      /* Purple color for emojis */
      margin-bottom: 15px;
    }
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-light shadow-sm">
    <div class="container">
      <a class="navbar-brand d-flex align-items-center" href="#">
        <img src="Untitled design.png" alt="Logo">
        <span class="fw-bold fs-3 ms-3" style="color: #531eee">Tipawan Salon</span>
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link fw-semibold" href="#services">Services</a></li>
          <li class="nav-item"><a class="nav-link fw-semibold" href="#about">About</a></li>
          <li class="nav-item"><a class="nav-link fw-semibold" href="#gallery">Gallery</a></li>
          <li class="nav-item"><a class="nav-link fw-semibold" href="#contact">Contact</a></li>
          <li class="nav-item"><a class="nav-link fw-semibold" href="logout2.php">Logout</a></li>

          <li class="nav-item dropdown ms-3">
            <a class="nav-link position-relative" href="#" id="notificationBell" data-bs-toggle="dropdown" aria-expanded="false">
              <i class="fas fa-bell" style="font-size: 24px; color: #6235e7;"></i>
              <?php if ($unread_count > 0): ?>
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                  <?php echo $unread_count; ?>
                  <span class="visually-hidden">unread messages</span>
                </span>
              <?php endif; ?>
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationBell">
              <?php
              $count = 0;
              if ($notifications_result->num_rows > 0) {
                while ($notification = $notifications_result->fetch_assoc()) {
                  if ($count >= 3) break;
              ?>
                  <li class="dropdown-item">
                    <p class="mb-1"><?php echo htmlspecialchars($notification['message']); ?></p>
                    <small class="text-muted"><?php echo date('F j, Y, g:i a', strtotime($notification['created'])); ?></small>
                  </li>
                  <div class="dropdown-divider"></div>
              <?php
                  $count++;
                }
              } else {
                echo '<li class="dropdown-item">No new notifications.</li>';
              }
              ?>
              <li class="dropdown-item text-center">
                <small><i><a href="all_notification.php" class="notification-link">View all notifications</a></i></small>
              </li>
            </ul>
          </li>

        </ul>
      </div>
    </div>
  </nav>

  <div class="hero">
    <div class="hero-content">
      <h1>Tipawan Salon Management System</h1>
      <p style="font-size: 1.5rem">YOUR STYLE ✂ , YOUR FASHION 🕊, YOUR PASSION 🙌 </p>
      <p>Open 24/7 for all your beauty needs</p>
      <a href="appointment.php" class="btn btn-lg px-5 py-3" style="background-color: #dfd1ff; color: #6235e7">Make an Appointment</a>
    </div>
  </div>

  <section id="services" class="bg-light">
    <div class="container text-center">
      <h2>Our Services</h2>
      <p class="lead">We provide high-quality salon services tailored to your needs.</p>
      <div class="row">
        <table class="table table-bordered table-striped text-center">
          <thead>
            <tr>
              <th>Service Number</th>
              <th>Service Name</th>
              <th>Description</th>
              <th>Cost</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($service_result->num_rows > 0) {
              while ($service = $service_result->fetch_assoc()) { ?>
                <tr>
                  <td><?php echo htmlspecialchars($service['service_id']); ?></td>
                  <td><?php echo htmlspecialchars($service['ServiceName']); ?></td>
                  <td><?php echo htmlspecialchars($service['Description']); ?></td>
                  <td>₱<?php echo htmlspecialchars($service['Cost']); ?></td>
                </tr>
              <?php }
            } else { ?>
              <tr>
                <td colspan="4" class="text-center">No services found.</td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </section>

  <section id="mivision" class="py-5">
    <div class="container text-center">
      <h2 class="mb-4 fw-bold text-uppercase">Mission & Vision</h2>
      <div class="row g-4">

        <div class="col-md-6">
          <div class="card shadow border-0">
            <div class="card-body p-4">
              <h5 class="card-title text-uppercase text-primary fw-bold">Our Mission</h5>
              <p class="card-text mt-3 text-muted" style="text-align: justify">
                At our salon management system, our mission is to provide top-notch salon services to our clients by using high-quality products, providing personalized attention, and creating a relaxing atmosphere. We strive to exceed our clients' expectations by staying up-to-date with the latest trends and techniques, while also maintaining an eco-friendly and sustainable approach to our business.
              </p>
            </div>
          </div>
        </div>

        <div class="col-md-6">
          <div class="card shadow border-0">
            <div class="card-body p-4">
              <h5 class="card-title text-uppercase text-primary fw-bold">Our Vision</h5>
              <p class="card-text mt-3 text-muted" style="text-align: justify">
                Our vision is to become a leading salon management system by empowering salon owners to streamline their operations, enhance their customer experiences, and increase their profitability. We aim to achieve this vision by leveraging cutting-edge technology, fostering a culture of innovation and collaboration, and providing unparalleled customer service to our clients.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section id="wecando">
    <div class="container">
      <h2>What We Do</h2>
      <div class="service">
        <h3>☑ Haircuts</h3>
        <p>Our stylists and barbers are experts in men's haircuts, from classic cuts to modern styles. We take the time to understand your individual style and preferences, so you can trust us to deliver the perfect cut every time.</p>
      </div>
      <div class="service">
        <h3>☑ Beard and Mustache Grooming</h3>
        <p>Whether you're looking to keep your beard neat and tidy or want to try out a new style, our barbers have the skills and expertise to help you achieve the perfect look.</p>
      </div>
      <div class="service">
        <h3>☑ Shaves</h3>
        <p>There's nothing like a hot towel shave to leave you feeling refreshed and rejuvenated. Our barbers use the latest techniques and premium products to give you the closest, smoothest shave possible.</p>
      </div>
      <div class="service">
        <h3>☑ Coloring</h3>
        <p>Whether you want to cover up gray hair or try out a new look, our stylists can help you achieve the perfect hair color to suit your style and personality.</p>
      </div>
      <div class="service">
        <h3>☑ Styling</h3>
        <p>From special occasions to everyday looks, our stylists can help you achieve the perfect style to suit any occasion. We use the latest techniques and products to ensure that your hair looks great all day.</p>
      </div>
    </div>
  </section>

  <section id="whychooseus">
    <div class="container">
      <h1>Why Choose Us?</h1>
      <div class="row">
        <div class="feature">
          <div class="icon">✂</div>
          <h2>Experienced Stylists</h2>
          <p>Our stylists have years of experience and are always up-to-date with the latest styles and techniques.</p>
        </div>
        <div class="feature">
          <div class="icon">🏆</div>
          <h2>Quality Service</h2>
          <p>We pride ourselves on providing top-notch service and ensuring every customer leaves our salon looking and feeling great.</p>
        </div>
        <div class="feature">
          <div class="icon">💰</div>
          <h2>Affordable Prices</h2>
          <p>Our prices are competitive, and we offer a variety of packages and deals to ensure you get the most value for your money.</p>
        </div>
      </div>
    </div>
  </section>

  <section id="about">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-md-6">
          <img src="hair-stylist-washing-mature-woman-hair.webp" class="img-fluid rounded" alt="About Us">
        </div>
        <div class="col-md-6 text-center text-md-start">
          <h2>About Us</h2>
          <p class="lead">
            At Tipawan Salon, we are committed to excellence and your satisfaction.
            Our team of professional stylists and beauty experts are here to bring your vision to life. Our main focus is on quality and hygiene. Our Parlour is well equipped with advanced technology equipments and provides best quality services. Our staff is well trained and experienced, offering advanced services in Skin, Hair and Body Shaping that will provide you with a luxurious experience that leave you feeling relaxed and stress free. The specialities in the parlour are, apart from regular bleachings and Facials, many types of hairstyles, Bridal and cine make-up and different types of Facials & fashion hair colourings.quality services.
          </p>
          <p>
            Experience the best in hair care, skin treatments, and beauty services.
            Your style is our passion.
          </p>
        </div>
      </div>
    </div>
  </section>

  <section id="gallery" class="" style="background-color: #dfd1ff">
    <div class="container text-center">
      <h2>Gallery</h2>
      <div class="row">
        <div class="col-md-4"><img src="woman-washing-hair-in-hair-salon.webp" alt="Gallery 1" class="img-fluid"></div>
        <div class="col-md-4"><img src="TheNetworkSalon_GretaCurlingAClientsHair-71efd597-1920w.webp" alt="Gallery 2" class="img-fluid"></div>
        <div class="col-md-4"><img src="smiling-barber-cutting-customers-hair-in-salon.webp" alt="Gallery 3" class="img-fluid"></div>
        <div class="col-md-4"><img src="woman-getting-her-hair-washed-in-hair-salon.webp" alt="Gallery 4" class="img-fluid"></div>
        <div class="col-md-4"><img src="salon.webp" alt="Gallery 5" class="img-fluid"></div>
        <div class="col-md-4"><img src="hairdresser-dyeing-clients-hair-at-hair-salon.webp" alt="Gallery 6" class="img-fluid"></div>
      </div>
    </div>
  </section>

  <section id="contact" class="bg-light py-5">
    <div class="container">
      <h2 class="text-center mb-4" style="color:#531eee">Contact Us</h2>
      <div class="row">
        <div class="col-md-4">
          <h4 class="mb-3" style="color: #531eee">Salon Address</h4>
          <address>
            <p class="mb-2">
              <strong>📍 Tipawan Salon</strong>
              1234 Style Avenue,
              Fashion District,
              Metro City, 1001
            </p>
          </address>
          <p>📱 09092034481</p>
          <p>📧 rickymerdo@gmail.com</p>
        </div>

        <div class="col-md-4">
          <h4 class="mb-3" style="color: #531eee">Follow Us</h4>
          <p class="mb-3">Stay connected through our social channels:</p>
          <div class="d-flex gap-3">
            <a href="https://facebook.com" target="_blank" class="btn btn-primary">
              <i class="bi bi-facebook"></i> Facebook
            </a>
            <a href="https://instagram.com" target="_blank" class="btn btn-danger">
              <i class="bi bi-instagram"></i> Instagram
            </a>
            <a href="https://twitter.com" target="_blank" class="btn btn-info">
              <i class="bi bi-twitter"></i> Twitter
            </a>
          </div>
        </div>

        <div class="subscribe col-md-4">
          <h4 class="mb-3" style="color: #531eee">Subscribe for Updates</h4>
          <form action="subscribe.php" method="POST">
            <div class="input-group">
              <input
                type="email"
                name="email"
                class="form-control"
                placeholder="Your Email"
                aria-label="Subscribe"
                required>
              <button class="btn btn-success" type="submit">Subscribe</button>
            </div>
            <p class="text-muted mt-2">Get the latest news, and discounts from Tipawan Salon directly in your notification bell above.</p>
          </form>
        </div>

      </div>
    </div>
    </div>
  </section>

  <div class="footer">
    <p class="text-center" style="color:#531eee">© Tipawan Salon Management System 2024</p>
  </div>


  <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
  <script>
    const navbar = document.querySelector('.navbar');
    window.addEventListener('scroll', () => {
      if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    });
  </script>
</body>

</html>
<style>
  /* General Styling */
  #mivision {
    background-color: #fdf9f6;
    /* Soft neutral background */
    font-family: 'Poppins', sans-serif;
    /* Elegant, clean font */
  }

  /* Section Title */
  #mivision h2 {
    color: #531eee;
    /* Warm tone for a luxurious feel */
    letter-spacing: 1.5px;
  }

  /* Card Styling */
  #mivision .card {
    border-radius: 12px;
    transition: transform 0.3s, box-shadow 0.3s;
  }

  #mivision .card:hover {
    transform: scale(1.05);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
  }

  #mivision .card-title {
    font-size: 1.2rem;
  }

  #mivision .card-text {
    font-size: 1rem;
    line-height: 1.6;
    color: #6c757d;
    /* Subtle, muted text color */
  }

  /* Responsive Enhancements */
  @media (max-width: 768px) {
    #mivision h2 {
      font-size: 1.75rem;
    }

    #mivision .card-title {
      font-size: 1rem;
    }
  }

  /* General Styling */
  #about {
    background-color: #faf8f6;
    /* Soft background for elegance */
    font-family: 'Poppins', sans-serif;
    /* Elegant, professional font */
  }

  #about h2 {
    color: #5a3e2b;
    /* Sophisticated tone */
    letter-spacing: 1px;
  }

  #about p {
    line-height: 1.8;
  }

  #about img {
    border-radius: 12px;
    /* Rounded corners for a modern touch */
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
    /* Subtle shadow */
  }

  #about .text-primary {
    color: #5a3e2b;
    /* Warm and inviting color for headings */
  }

  #about .text-secondary {
    color: #8e6b50;
    /* Supporting tone for emphasis */
  }

  #about .lead {
    font-size: 1.1rem;
  }

  /* Responsive Enhancements */
  @media (max-width: 768px) {
    #about h2 {
      font-size: 1.8rem;
    }

    #about p {
      font-size: 1rem;
    }
  }

  /* General Styling */
  #gallery {
    font-family: 'Poppins', sans-serif;
    /* Elegant and modern font */
  }

  #gallery h2 {
    color: #5a3e2b;
    /* Warm tone for headings */
    letter-spacing: 1px;
  }

  #gallery .gallery-item img {
    border-radius: 12px;
    /* Smooth, modern rounding */
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
    /* Soft shadow for depth */
    transition: transform 0.3s, box-shadow 0.3s;
  }

  #gallery .gallery-item img:hover {
    transform: scale(1.05);
    /* Slight zoom on hover */
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
    /* Elevated shadow on hover */
  }

  /* Responsive Enhancements */
  @media (max-width: 768px) {
    #gallery h2 {
      font-size: 1.8rem;
    }
  }

  #wecando {
    padding: 50px 20px;
    background: #ffffff;
    /* Clean white background */
  }

  #wecando .container {
    max-width: 1200px;
    margin: auto;
    text-align: center;
  }

  #wecando h2 {
    font-size: 2.5rem;
    font-weight: bold;
    color: #6b46c1;
    /* Elegant purple */
    margin-bottom: 30px;
    position: relative;
  }

  #wecando h2::after {
    content: '';
    display: block;
    width: 80px;
    height: 4px;
    background: #9f7aea;
    /* Accent purple */
    margin: 10px auto 0;
    border-radius: 2px;
  }

  #wecando .service {
    margin-bottom: 30px;
    text-align: left;
    padding: 20px;
    border: 1px solid #e0e0e0;
    /* Subtle border for separation */
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s, box-shadow 0.3s;
    background: #fdfdfd;
    /* Slightly off-white for cards */
  }

  #wecando .service:hover {
    transform: scale(1.02);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
  }

  #wecando .service h3 {
    font-size: 1.5rem;
    color: #4c1d95;
    /* Deep purple for headings */
    margin-bottom: 10px;
  }

  #wecando .service p {
    font-size: 1rem;
    line-height: 1.6;
    color: #444444;
    /* Neutral dark gray for readability */
  }

  #wecando .service p span {
    color: #6b46c1;
    /* Highlighted keywords with purple */
    font-weight: bold;
  }

  @media (max-width: 768px) {
    #wecando h2 {
      font-size: 2rem;
    }

    #wecando .service {
      text-align: center;
    }
  }

  #whychooseus {
    padding: 60px 20px;
    background-color: #ffffff;
    text-align: center;
  }

  #whychooseus h1 {
    font-size: 2.5rem;
    font-weight: bold;
    color: #6b46c1;
    /* Elegant purple for headings */
    margin-bottom: 40px;
    position: relative;
  }

  #whychooseus h1::after {
    content: '';
    display: block;
    width: 100px;
    height: 4px;
    background: #9f7aea;
    /* Purple accent line */
    margin: 10px auto 0;
    border-radius: 2px;
  }

  #whychooseus .row {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;
  }

  #whychooseus .feature {
    background-color: #fdfdfd;
    /* Subtle card background */
    border: 1px solid #e0e0e0;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
    padding: 20px;
    max-width: 300px;
    width: 100%;
    transition: transform 0.3s, box-shadow 0.3s;
  }

  #whychooseus .feature:hover {
    transform: scale(1.05);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
  }

  #whychooseus .feature h2 {
    font-size: 1.5rem;
    font-weight: bold;
    color: #4c1d95;
    /* Dark purple for subheadings */
    margin-bottom: 15px;
  }

  #whychooseus .feature p {
    font-size: 1rem;
    line-height: 1.6;
    color: #444444;
    /* Neutral gray for text */
    margin: 0;
  }

  @media (max-width: 768px) {
    #whychooseus h1 {
      font-size: 2rem;
    }

    #whychooseus .row {
      flex-direction: column;
      align-items: center;
    }
  }

  #whychooseus .feature .icon {
    font-size: 3rem;
    /* Increase emoji size */
    color: #6b46c1;
    /* Purple color for emojis */
    margin-bottom: 15px;
  }
</style>