<?php
require 'connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $conn->real_escape_string($_POST['email']);
    
    $checkQuery = "SELECT * FROM subscribers WHERE email = '$email'";
    $result = $conn->query($checkQuery);

    if ($result->num_rows > 0) {
        echo "<script>
                alert('You are already subscribed!');
                window.location.href = 'index2.php';
              </script>";
    } else {
        $query = "INSERT INTO subscribers (email) VALUES ('$email')";
        
        if ($conn->query($query) === TRUE) {
            echo "<script>
                    alert('Thank you for subscribing! Wait on the notification bell for more exciting offers!');
                    window.location.href = 'index2.php';
                  </script>";
        } else {
            echo "<script>
                    alert('Subscription failed. Please try again.');
                    window.location.href = 'index2.php';
                  </script>";
        }
    }
}
$conn->close();
?>
