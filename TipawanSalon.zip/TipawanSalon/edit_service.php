<?php
require 'connection.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

if (isset($_GET['id'])) {
    $serviceId = $_GET['id'];
    $query = "SELECT * FROM services WHERE service_id = '$serviceId'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $service = $result->fetch_assoc();
    } else {
        $_SESSION['error_message'] = "Service not found!";
        header("Location: manage_services.php");
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $serviceName = $conn->real_escape_string($_POST['ServiceName']);
    $cost = $conn->real_escape_string($_POST['Cost']);

    $updateQuery = "UPDATE services SET ServiceName = '$serviceName', Cost = '$cost' WHERE service_id = '$serviceId'";

    if ($conn->query($updateQuery) === TRUE) {
        $_SESSION['success_message'] = "Service updated successfully!";
    } else {
        $_SESSION['error_message'] = "Failed to update service. Please try again.";
    }
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Service</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="icon/fontawesome-free-6.7.1-web/css/all.min.css">
</head>
<style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f8f9fa;
        }

        .sidebar {
            height: 100vh;
            background-color: #7e57c2;
            color: #fff;
            padding: 30px 20px;
            position: fixed;
            width: 250px;
            box-shadow: 4px 0 10px rgba(0, 0, 0, 0.1);
        }

        .sidebar h3 {
            text-align: center;
            margin-bottom: 30px;
            font-weight: bold;
        }

        .sidebar a {
            color: #fff;
            text-decoration: none;
            padding: 10px 15px;
            display: block;
            border-radius: 5px;
            margin: 5px 0;
            transition: background-color 0.3s ease;
        }

        .sidebar a:hover {
            background-color: #6a4aa0;
        }

        .content {
            margin-left: 270px;
            padding: 20px;
        }

        .header {
            background-color: #7e57c2;
            color: #fff;
            padding: 20px;
            border-radius: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .header h2 {
            margin: 0;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f1f1f1;
            font-weight: bold;
            color: #333;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .btn {
            font-size: 14px;
            padding: 8px 12px;
            border-radius: 5px;
        }

        .btn-warning {
            background-color: #ff9800;
            border-color: #ff9800;
        }

        .btn-danger {
            background-color: #f44336;
            border-color: #f44336;
        }

        .btn-warning:hover {
            background-color: #fb8c00;
            border-color: #fb8c00;
        }

        .btn-danger:hover {
            background-color: #e53935;
            border-color: #e53935;
        }

        .table-container {
            overflow-x: auto;
        }
</style>
<body>
<div class="sidebar">
        <h3>Admin Panel</h3>
        <a href="admin_dashboard.php"><i class="fas fa-chart-line"></i> Dashboard</a>
        <a href="manage_appointments.php"><i class="fas fa-calendar-alt"></i> Manage Appointments</a>

        <div class="dropdown">
            <button class="btn dropdown-toggle w-100 text-start text-white" id="servicesDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-concierge-bell"></i> Manage Services
            </button>
            <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="servicesDropdown">
                <li><a class="dropdown-item" href="manage_services.php">View Services</a></li>
                <li><a class="dropdown-item" href="add_service.php">Add Service</a></li>
            </ul>
        </div>

        <a href="invoices.php"><i class="fas fa-file-invoice"></i> Manage Invoices</a>
        <a href="notification.php"><i class="fa-solid fa-bell"></i> Notification</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <div class="content">
    <h2 class="header">Edit Service</h2>

    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success_message']; ?>
        </div>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>

    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error_message']; ?>
        </div>
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>

    <form action="" method="POST" class="mt-4">
        <div class="mb-3">
            <label for="ServiceName" class="form-label">Service Name</label>
            <input 
                type="text" 
                class="form-control" 
                id="ServiceName" 
                name="ServiceName" 
                placeholder="Enter Service Name" 
                value="<?php echo htmlspecialchars($service['ServiceName'], ENT_QUOTES); ?>" 
                required 
            >
        </div>

        <div class="mb-3">
            <label for="Cost" class="form-label">Service Cost (₱)</label>
            <input 
                type="number" 
                class="form-control" 
                id="Cost" 
                name="Cost" 
                placeholder="Enter Service Cost" 
                step="0.01" 
                min="0" 
                value="<?php echo htmlspecialchars($service['Cost'], ENT_QUOTES); ?>" 
                required 
            >
        </div>

        <div class="d-flex justify-content-between">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Update Service
            </button>
            <a href="manage_services.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back
            </a>
        </div>
    </form>
</div>


</body>
</html>
