<?php
require 'connection.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

$appointmentId = isset($_GET['id']) ? $_GET['id'] : null;

if ($appointmentId === null) {
    header("Location: manage_appointments.php");
    exit();
}

$query = "SELECT * FROM appointment WHERE apt_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $appointmentId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: manage_appointments.php");
    exit();
}

$appointment = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $mobile_number = $conn->real_escape_string($_POST['mobile_number']);
    $gender = $conn->real_escape_string($_POST['gender']);
    
    $apt_date = date('Y-m-d', strtotime($_POST['apt_date']));
    $apt_time = date('H:i:s', strtotime($_POST['apt_time']));
    
    $service_id = intval($_POST['service_id']);

    $updateQuery = "UPDATE appointment SET name = ?, email = ?, mobile_number = ?, gender = ?, apt_date = ?, apt_time = ?, service_id = ? WHERE apt_id = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("ssssssii", $name, $email, $mobile_number, $gender, $apt_date, $apt_time, $service_id, $appointmentId);

    if ($stmt->execute()) {
        $successMessage = "Appointment updated successfully!";
    } else {
        $errorMessage = "Error: " . $stmt->error;
    }
}


$serviceQuery = "SELECT * FROM services";
$servicesResult = $conn->query($serviceQuery);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Appointment</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="icon/fontawesome-free-6.7.1-web/css/all.min.css">
    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f8f9fa;
        }

        .sidebar {
            height: 100vh;
            background-color: #7e57c2;
            color: #fff;
            padding: 30px 20px;
            position: fixed;
            width: 250px;
            box-shadow: 4px 0 10px rgba(0, 0, 0, 0.1);
        }

        .sidebar h3 {
            text-align: center;
            margin-bottom: 30px;
            font-weight: bold;
        }

        .sidebar a {
            color: #fff;
            text-decoration: none;
            padding: 10px 15px;
            display: block;
            border-radius: 5px;
            margin: 5px 0;
            transition: background-color 0.3s ease;
        }

        .sidebar a:hover {
            background-color: #6a4aa0;
        }

        .content {
            margin-left: 270px;
            padding: 20px;
        }

        .form-container {
            max-width: 600px;
            margin: 40px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .btn-primary {
            background-color: #7e57c2;
            border-color: #7e57c2;
        }

        .btn-primary:hover {
            background-color: #6a4aa0;
            border-color: #6a4aa0;
        }
    </style>
</head>
<body>
<div class="sidebar">
        <h3>Admin Panel</h3>
        <a href="admin_dashboard.php"><i class="fas fa-chart-line"></i> Dashboard</a>
        <a href="manage_appointments.php"><i class="fas fa-calendar-alt"></i> Manage Appointments</a>

        <div class="dropdown">
            <button class="btn dropdown-toggle w-100 text-start text-white" id="servicesDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-concierge-bell"></i> Manage Services
            </button>
            <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="servicesDropdown">
                <li><a class="dropdown-item" href="manage_services.php">View Services</a></li>
                <li><a class="dropdown-item" href="add_service.php">Add Service</a></li>
            </ul>
        </div>

        <a href="invoices.php"><i class="fas fa-file-invoice"></i> Manage Invoices</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <div class="content">
        <div class="form-container">
            <h2 class="text-center">Edit Appointment</h2>
            <hr>
            <?php if (isset($successMessage)): ?>
                <div class="alert alert-success"><?php echo $successMessage; ?></div>
            <?php endif; ?>

            <?php if (isset($errorMessage)): ?>
                <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
            <?php endif; ?>

            <form method="POST" action="edit_appointment.php?id=<?php echo $appointmentId; ?>">
                <div class="mb-3">
                    <label for="name" class="form-label">Customer Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($appointment['name']); ?>" required>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($appointment['email']); ?>" required>
                </div>

                <div class="mb-3">
                    <label for="mobile_number" class="form-label">Mobile Number</label>
                    <input type="text" class="form-control" id="mobile_number" name="mobile_number" value="<?php echo htmlspecialchars($appointment['mobile_number']); ?>" required>
                </div>

                <div class="mb-3">
                    <label for="gender" class="form-label">Gender</label>
                    <select class="form-control" id="gender" name="gender">
                        <option value="Male" <?php echo $appointment['gender'] === 'Male' ? 'selected' : ''; ?>>Male</option>
                        <option value="Female" <?php echo $appointment['gender'] === 'Female' ? 'selected' : ''; ?>>Female</option>
                        <option value="Other" <?php echo $appointment['gender'] === 'Other' ? 'selected' : ''; ?>>Other</option>
                    </select>
                </div>

                <div class="mb-3">
    <label for="apt_date" class="form-label">Appointment Date</label>
    <input type="date" class="form-control" id="apt_date" name="apt_date" value="<?php echo htmlspecialchars($appointment['apt_date']); ?>" required min="<?php echo date('Y-m-d'); ?>">
</div>

<div class="mb-3">
    <label for="apt_time" class="form-label">Appointment Time</label>
    <input type="time" class="form-control" id="apt_time" name="apt_time" value="<?php echo htmlspecialchars($appointment['apt_time']); ?>" required>
</div>


                <div class="mb-3">
                    <label for="service_id" class="form-label">Service</label>
                    <select class="form-control" id="service_id" name="service_id">
                        <?php while ($service = $servicesResult->fetch_assoc()): ?>
                            <option value="<?php echo $service['service_id']; ?>" <?php echo $service['service_id'] == $appointment['service_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($service['ServiceName']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary w-100">Update Appointment</button>
            </form>
        </div>
    </div>
</body>
</html>
<style>
    /* Sidebar Dropdown Styling */
    .sidebar .dropdown {
        position: relative;
    }

    .sidebar .dropdown-toggle {
        font-size: 16px;
        background: none;
        border: none;
        color: white;
        text-align: left;
        width: 100%;
    }

    .sidebar .dropdown-menu {
        position: absolute;
        left: 0;
        top: 100%;
        background-color: #6a4aa0;
        border: none;
        border-radius: 5px;
        width: 100%;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        z-index: 1000;
    }

    .sidebar .dropdown-menu .dropdown-item {
        color: white;
        padding: 10px 15px;
        font-size: 14px;
        transition: background-color 0.3s ease;
    }

    .sidebar .dropdown-menu .dropdown-item:hover {
        background-color: #5a3c8c;
    }

    .sidebar .dropdown-menu::before {
        content: '';
        position: absolute;
        top: -8px;
        left: 20px;
        border-width: 0 8px 8px 8px;
        border-style: solid;
        border-color: transparent transparent #6a4aa0 transparent;
    }
</style>