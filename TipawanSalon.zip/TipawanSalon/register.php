<?php
require 'connection.php';

$message = '';

if (isset($_POST['submit'])) {
    $user = $_POST['user'];
    $pass = $_POST['pass'];

    $query = "SELECT * FROM `user` WHERE `username` = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $user);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if (strlen($user) < 8 || strlen($pass) < 8) {
        $message = '<p class="text-danger">Username and Password must be at least 8 characters long!</p>';
    } elseif ($row) {
        $message = '<p class="text-danger">User already exists! Please try another username!</p>';
    } else {
        $hashedPass = password_hash($pass, PASSWORD_DEFAULT);

        $sql = "INSERT INTO `user` (`username`, `password`) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $user, $hashedPass);

        if ($stmt->execute()) {
            echo '<script>alert("Registered Successfully!"); window.location.href = "login.php"; </script>';
        } else {
            $message = '<p class="text-danger">Failed to register. Please try again later.</p>';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Salon Registration</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <style>
        /* General Styling */
        body {
            font-family: 'Poppins', sans-serif;
            background-image: linear-gradient(to right, #667eea, #764ba2);
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            background-color: #7e57c2; /* Salon-theme purple */
            color: #fff;
            border-top-left-radius: 15px;
            border-top-right-radius: 15px;
        }
        .btn-primary {
            background-color: #7e57c2;
            border-color: #7e57c2;
        }
        .btn-primary:hover {
            background-color: #6a4aa0;
            border-color: #6a4aa0;
        }
        .form-control:focus {
            border-color: #7e57c2;
            box-shadow: 0 0 5px rgba(126, 87, 194, 0.5);
        }
        a {
            color: #7e57c2;
            text-decoration: none;
        }
        a:hover {
            color: #6a4aa0;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header text-center">
                    <h4>Register for Tipawan Salon</h4>
                </div>
                <div class="card-body">
                    <?php echo $message; ?>
                    <form method="post">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" name="user" id="username" class="form-control" placeholder="Enter Username" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" name="pass" id="password" class="form-control" placeholder="Enter Password" required>
                        </div>
                        <button type="submit" name="submit" class="btn btn-primary w-100">Register</button>
                        <div class="mt-3 text-center">
                            <span>Already have an account?</span> 
                            <a href="login.php">Login here!</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
