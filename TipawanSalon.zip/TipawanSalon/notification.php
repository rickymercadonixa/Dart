<?php
require 'connection.php'; // Include database connection

// Fetch all users to choose the recipient (optional, depending on your needs)
$query = "SELECT user_id, username FROM user";
$result = $conn->query($query);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id']; // User to send notification to
    $message = $_POST['message']; // The message to send

    // Insert the message into the notifications table
    $stmt = $conn->prepare("INSERT INTO notification (user_id, message) VALUES (?, ?)");
    $stmt->bind_param("is", $user_id, $message);
    $stmt->execute();

    // Redirect with success message
    header("Location: notification.php?notification=success");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Notification</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="icon/fontawesome-free-6.7.1-web/css/all.min.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
        }

        .sidebar {
            background-color: #6a4aa0; /* Purple shade */
            color: white;
            height: 100vh;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            padding: 20px;
            box-shadow: 4px 0px 10px rgba(0, 0, 0, 0.1);
        }

        .sidebar h3 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .sidebar a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 12px 20px;
            font-size: 16px;
            margin-bottom: 12px;
            transition: background-color 0.3s ease;
        }

        .sidebar a:hover {
            background-color: #5a3c8c; /* Darker purple */
            border-radius: 5px;
        }

        .sidebar .dropdown-menu {
            background-color: #5a3c8c; /* Darker purple */
        }

        .sidebar .dropdown-menu .dropdown-item {
            color: white;
        }

        .sidebar .dropdown-menu .dropdown-item:hover {
            background-color: #4b2f76; /* Darker shade on hover */
        }

        .content-wrapper {
            margin-left: 270px;
            padding: 30px;
            background-color: #f8f9fa;
            min-height: 100vh;
        }

        .content-wrapper .form-container {
            background-color: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .form-container h2 {
            font-size: 28px;
            margin-bottom: 30px;
            color: #6a4aa0; /* Purple title */
        }

        .form-container .alert {
            margin-bottom: 30px;
        }

        .form-container label {
            font-weight: 500;
            margin-bottom: 10px;
            color: #6a4aa0; /* Purple label */
        }

        .form-container select, .form-container textarea {
            border-radius: 5px;
            padding: 10px;
            font-size: 16px;
            width: 100%;
            margin-bottom: 20px;
            border: 1px solid #ccc;
        }

        .form-container textarea {
            resize: vertical;
            height: 150px;
        }

        .form-container button {
            background-color: #6a4aa0; /* Purple button */
            color: white;
            border: none;
            padding: 12px 25px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .form-container button:hover {
            background-color: #5a3c8c; /* Darker purple button on hover */
        }

        .sidebar .dropdown-menu::before {
            content: '';
            position: absolute;
            top: -8px;
            left: 20px;
            border-width: 0 8px 8px 8px;
            border-style: solid;
            border-color: transparent transparent #6a4aa0 transparent;
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <h3>Admin Panel</h3>
        <a href="admin_dashboard.php"><i class="fas fa-chart-line"></i> Dashboard</a>
        <a href="manage_appointments.php"><i class="fas fa-calendar-alt"></i> Manage Appointments</a>

        <div class="dropdown">
            <button class="btn dropdown-toggle w-100 text-start text-white" id="servicesDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-concierge-bell"></i> Manage Services
            </button>
            <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="servicesDropdown">
                <li><a class="dropdown-item" href="manage_services.php">View Services</a></li>
                <li><a class="dropdown-item" href="add_service.php">Add Service</a></li>
            </ul>
        </div>

        <a href="invoices.php"><i class="fas fa-file-invoice"></i> Manage Invoices</a>
        <a href="notification.php"><i class="fa-solid fa-bell"></i> Notification</a>
        <a href="subscriber.php"><i class="fa-solid fa-user"></i> Subscribers</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <div class="content-wrapper">
        <div class="form-container">
            <h2>Send Notification to User</h2>

            <?php if (isset($_GET['notification']) && $_GET['notification'] == 'success'): ?>
                <div class="alert alert-success">Notification sent successfully!</div>
            <?php endif; ?>

            <form action="" method="POST">
                <!-- Select a user -->
                <div class="mb-3">
                    <label for="user_id" class="form-label">Select User</label>
                    <select name="user_id" id="user_id" class="form-select" required>
                        <option value="" disabled selected>Select a user</option>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <option value="<?php echo $row['user_id']; ?>"><?php echo $row['username']; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <!-- Message input -->
                <div class="mb-3">
                    <label for="message" class="form-label">Message</label>
                    <textarea name="message" id="message" class="form-control" rows="4" required></textarea>
                </div>

                <button type="submit" class="btn btn-primary">Send Notification</button>
            </form>
        </div>
    </div>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<style>
    /* Sidebar Dropdown Styling */
    .sidebar .dropdown {
        position: relative;
    }

    .sidebar .dropdown-toggle {
        font-size: 16px;
        background: none;
        border: none;
        color: white;
        text-align: left;
        width: 100%;
    }

    .sidebar .dropdown-menu {
        position: absolute;
        left: 0;
        top: 100%;
        background-color: #6a4aa0;
        border: none;
        border-radius: 5px;
        width: 100%;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        z-index: 1000;
    }

    .sidebar .dropdown-menu .dropdown-item {
        color: white;
        padding: 10px 15px;
        font-size: 14px;
        transition: background-color 0.3s ease;
    }

    .sidebar .dropdown-menu .dropdown-item:hover {
        background-color: #5a3c8c;
    }

    .sidebar .dropdown-menu::before {
        content: '';
        position: absolute;
        top: -8px;
        left: 20px;
        border-width: 0 8px 8px 8px;
        border-style: solid;
        border-color: transparent transparent #6a4aa0 transparent;
    }
</style>
<style>
        body {
            font-family: 'Poppins', sans-serif;
        }

        .sidebar {
            height: 100vh;
            background-color: #7e57c2;
            color: #fff;
            padding: 15px;
            position: fixed;
            width: 250px;
        }

        .sidebar h3 {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar a {
            color: #fff;
            text-decoration: none;
            padding: 10px 15px;
            display: block;
            border-radius: 5px;
            margin: 5px 0;
        }

        .sidebar a:hover {
            background-color: #6a4aa0;
        }

        .content {
            margin-left: 270px;
            padding: 20px;
        }

        .header {
            background-color: #7e57c2;
            color: #fff;
            padding: 15px;
            border-radius: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header img {
            height: 50px;
        }

        .card {
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .sales-chart {
            background-color: #f9f6ff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
    </style>