<?php
require 'connection.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

$query = "SELECT sub_id, email FROM subscribers";
$result = $conn->query($query);

if (!$result) {
    echo "Error fetching subscribers: " . $conn->error;
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subscribers</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="icon/fontawesome-free-6.7.1-web/css/all.min.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f8f9fa;
        }

        .container {
            max-width: 800px;
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .container h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #7e57c2;
        }

        .subscriber-table {
            margin-top: 20px;
        }

        .subscriber-table th, .subscriber-table td {
            text-align: left;
            padding: 10px;
            border: 1px solid #ddd;
        }

        .subscriber-table th {
            background-color: #7e57c2;
            color: #fff;
        }

        .back-link {
            margin-top: 30px;
            text-align: center;
            font-size: 14px;
        }

        .back-link a {
            color: #7e57c2;
            text-decoration: none;
        }

        .back-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
<div class="sidebar">
        <h3>Admin Panel</h3>
        <a href="admin_dashboard.php"><i class="fas fa-chart-line"></i> Dashboard</a>
        <a href="manage_appointments.php"><i class="fas fa-calendar-alt"></i> Manage Appointments</a>

        <div class="dropdown">
            <button class="btn dropdown-toggle w-100 text-start text-white" id="servicesDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-concierge-bell"></i> Manage Services
            </button>
            <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="servicesDropdown">
                <li><a class="dropdown-item" href="manage_services.php">View Services</a></li>
                <li><a class="dropdown-item" href="add_service.php">Add Service</a></li>
            </ul>
        </div>

        <a href="invoices.php"><i class="fas fa-file-invoice"></i> Manage Invoices</a>
        <a href="notification.php"><i class="fa-solid fa-bell"></i> Notification</a>
        <a href="subscriber.php"><i class="fa-solid fa-user"></i> Subscribers</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <div class="container">
        <h2>Subscribers List</h2>
        <div class="subscriber-table">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th class="text-center">Subscriber ID</th>
                        <th class="text-center">Email</th>
                        <th class="text-center">Delete Subscriber</th>
                    </tr>
                </thead>
                <tbody>
    <?php if ($result->num_rows > 0): ?>
        <?php while ($subscriber = $result->fetch_assoc()): ?>
            <tr>
                <td class="text-center"><?php echo htmlspecialchars($subscriber['sub_id']); ?></td>
                <td class="text-center"><?php echo htmlspecialchars($subscriber['email']); ?></td>
                <td class="text-center">
                    <form method="POST" action="delete_subscriber.php" style="display:inline;">
                        <input type="hidden" name="sub_id" value="<?php echo $subscriber['sub_id']; ?>">
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this subscriber?');">
                            <i class="fas fa-trash-alt"></i> Delete
                        </button>
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr>
            <td colspan="3" class="text-center">No subscribers found.</td>
        </tr>
    <?php endif; ?>
</tbody>

            </table>
        </div>
    </div>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<style>
    /* Sidebar Dropdown Styling */
    .sidebar .dropdown {
        position: relative;
    }

    .sidebar .dropdown-toggle {
        font-size: 16px;
        background: none;
        border: none;
        color: white;
        text-align: left;
        width: 100%;
    }

    .sidebar .dropdown-menu {
        position: absolute;
        left: 0;
        top: 100%;
        background-color: #6a4aa0;
        border: none;
        border-radius: 5px;
        width: 100%;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        z-index: 1000;
    }

    .sidebar .dropdown-menu .dropdown-item {
        color: white;
        padding: 10px 15px;
        font-size: 14px;
        transition: background-color 0.3s ease;
    }

    .sidebar .dropdown-menu .dropdown-item:hover {
        background-color: #5a3c8c;
    }

    .sidebar .dropdown-menu::before {
        content: '';
        position: absolute;
        top: -8px;
        left: 20px;
        border-width: 0 8px 8px 8px;
        border-style: solid;
        border-color: transparent transparent #6a4aa0 transparent;
    }
</style>
<style>
        body {
            font-family: 'Poppins', sans-serif;
        }

        .sidebar {
            height: 100vh;
            background-color: #7e57c2;
            color: #fff;
            padding: 15px;
            position: fixed;
            width: 250px;
        }

        .sidebar h3 {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar a {
            color: #fff;
            text-decoration: none;
            padding: 10px 15px;
            display: block;
            border-radius: 5px;
            margin: 5px 0;
        }

        .sidebar a:hover {
            background-color: #6a4aa0;
        }

        .content {
            margin-left: 270px;
            padding: 20px;
        }

        .header {
            background-color: #7e57c2;
            color: #fff;
            padding: 15px;
            border-radius: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header img {
            height: 50px;
        }

        .card {
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .sales-chart {
            background-color: #f9f6ff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
    </style>