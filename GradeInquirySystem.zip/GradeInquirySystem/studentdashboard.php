<?php
    require 'connection.php';

$student_id = $_SESSION['guardian_id'] ?? 0;

$response_message = "";

$notifications_query = "SELECT message, date_created FROM notifications WHERE student_id = ? ORDER BY date_created DESC";
$notifications_stmt = $conn->prepare($notifications_query);
$notifications_stmt->bind_param("i", $student_id);
$notifications_stmt->execute();
$notifications_result = $notifications_stmt->get_result();

$unread_count_query = "SELECT COUNT(*) AS unread_count FROM notifications WHERE student_id = ? AND is_read = 0";
$unread_stmt = $conn->prepare($unread_count_query);
$unread_stmt->bind_param("i", $student_id);
$unread_stmt->execute();
$unread_result = $unread_stmt->get_result();
$unread_count = $unread_result->fetch_assoc()['unread_count'];

$query = "SELECT student_name FROM students WHERE student_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();
$student_name = $result->fetch_assoc()['student_name'] ?? 'Student';

$grades_query = "
SELECT grades.grade_id, grades.grade, grades.date_recorded, students.student_name, subjects.subject_name, teachers.teacher_name
FROM grades
JOIN students ON grades.student_id = students.student_id
JOIN subjects ON grades.subject_id = subjects.subject_id
JOIN teachers ON grades.teacher_id = teachers.teacher_id
WHERE grades.student_id = ?
";
$stmt = $conn->prepare($grades_query);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$grades_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Student Dashboard</title>
    <style>
        body {
            display: flex;
            min-height: 100vh;
            margin: 0;
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
        }

        /* Sidebar styling */
        .sidebar {
            width: 250px;
            background-color: #004d99;
            padding: 30px 10px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .sidebar img {
            width: 100%;
            margin-bottom: 20px;
        }

        .sidebar p {
            font-size: 1.2rem;
            color: #ffffff;
            margin-bottom: 30px;
            text-align: center;
        }

        .nav-items a {
            display: block;
            text-decoration: none;
            font-size: 1.1rem;
            color: #ffffff;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            text-align: left;
            transition: background-color 0.3s;
        }

        .nav-items a.active, .nav-items a:hover {
            background-color: #003366;
        }

        .btn-logout {
            background-color: #e74c3c;
            color: white;
            padding: 10px;
            text-align: center;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            margin-top: auto;
            transition: background-color 0.3s;
        }

        .btn-logout:hover {
            background-color: #c0392b;
        }

        /* Main content styling */
        .main-content {
            flex-grow: 1;
            padding: 30px;
            background-color: #fff;
        }

        .main-content h1 {
            font-size: 2rem;
            color: #333;
            margin-bottom: 20px;
        }

        .main-content p {
            font-size: 1.1rem;
            color: #555;
            line-height: 1.6;
        }

        .notification-link {
            display: block;
            text-align: center;
            margin-top: 10px;
            font-size: 0.9rem;
            color: #007bff;
            text-decoration: none;
        }
        .notification-link:hover {
            text-decoration: underline;
        }

    </style>
</head>
<body>
    <div class="sidebar">
        <img src="a-removebg-preview.png" alt="School Logo">
        <p>CEBUANO ELEMENTARY SCHOOL</p>
        <div class="nav-items">
            <a href="studentdashboard.php" class="nav_link">Dashboard</a>
            <a href="student_inquiry.php" class="nav_link">Inquiry Form</a>
        </div>
        <a href="student_logout.php" class="btn-logout">Logout</a>
    </div>

    <div class="main-content">
    <div class="dropdown mb-4" style="float: right;">
            <button class="btn btn-secondary" type="button" id="notificationDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                Notifications
                <?php if ($unread_count > 0): ?>
                    <span class="badge bg-danger"><?php echo $unread_count; ?></span>
                <?php endif; ?>
            </button>
            <ul class="dropdown-menu" aria-labelledby="notificationDropdown">
                <?php
                $count = 0;
                if ($notifications_result->num_rows > 0) {
                    while ($notification = $notifications_result->fetch_assoc()) {
                        if ($count >= 3) break;
                        ?>
                        <li class="dropdown-item">
                            <p class="mb-1"><?php echo htmlspecialchars($notification['message']); ?></p>
                            <small class="text-muted"><?php echo date('F j, Y, g:i a', strtotime($notification['date_created'])); ?></small>
                        </li>
                        <div class="dropdown-divider">
                        </div>
                        <?php
                        $count++;
                    }
                } else {
                    echo '<li class="dropdown-item">No new notifications.</li>';
                }
                ?>
                <?php  if($notifications_result -> num_rows > 3){

                }?>
                    
                        <small><i><a href="all_notification.php" class="notification-link">View all notifications</a></i></small>



            </ul>
        </div>
        <h1>Welcome to <?php echo htmlspecialchars($student_name); ?>!</h1>
        <p>This is where you can access all your academic information, including your grades and inquiry forms. Stay updated with school announcements and manage your academic progress.</p>

        <table class="table table-bordered table-striped text-center">
            <thead>
                <tr>
                    <th>Student Name</th>
                    <th>Subject</th>
                    <th>Grade</th>
                    <th>Date Recorded</th>
                    <th>Teacher Name</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($grades_result->num_rows > 0) {
                    while ($grade = $grades_result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($grade['student_name']); ?></td>
                            <td><?php echo htmlspecialchars($grade['subject_name']); ?></td>
                            <td><?php echo htmlspecialchars($grade['grade']); ?></td>
                            <td><?php echo htmlspecialchars($grade['date_recorded']); ?></td>
                            <td><?php echo htmlspecialchars($grade['teacher_name']); ?></td>
                        </tr>
                    <?php }
                } else { ?>
                    <tr>
                        <td colspan="6" class="text-center">No grades found.</td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    </div>
    
    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
