<?php
require 'connection.php';

$sql = "SELECT teachers.*, classes.class_name FROM teachers LEFT JOIN classes ON teachers.teacher_id = classes.teacher_id";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>View All Teachers</title>
    <style>
        .officials-list {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
        }

        .official-card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin: 10px;
            width: 250px;
            text-align: center;
            transition: transform 0.2s;
        }

        .official-card img {
            border-radius: 50%;
            width: 100px;
            height: 100px;
            object-fit: cover;
        }

        .official-card h3 {
            font-size: 18px;
            margin: 10px 0;
        }

        .official-card a {
            display: inline-block;
            padding: 10px 20px;
            background-color: #f0a500;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 10px;
        }

        .official-card:hover {
            transform: translateY(-10px);
        }

        body {
            display: flex;
            min-height: 100vh;
            margin: 0;
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
        }
    </style>
</head>

<body>
    <div class="col-md-12">
        <h2 class="text-center display-5">Teachers Info</h2>
        <div class="officials-list">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "
                                                <div class='official-card'>
                                            <img src='" . $row['photo'] . "' alt='Profile Picture'>
                                        <h3>" . $row['teacher_name'] . "</h3>
                                        <h3>" . $row['class_name'] . "</h3>
                                    <a href='viewteacher_profile.php?teacher_id=" . $row['teacher_id'] . "' class='btn'>View Profile</a>
                                </div>";
                }
            } else {
                echo "No teachers found.";
            }
            ?>
        </div>
        <a href="admin_dashboard.php" class="btn btn-danger col-md-12 mt-2">Back</a>
</body>

</html>