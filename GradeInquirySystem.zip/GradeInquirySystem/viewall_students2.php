<?php
require 'connection.php';

// Query to fetch student data along with class and teacher information
$query = "SELECT 
            students.student_number,
            students.student_name,
            students.date_of_birth,
            students.guardian_name,
            students.guardian_contact,
            students.date_enrolled,
            students.photo,
            classes.class_name,
            teachers.teacher_name
          FROM students
          JOIN classes ON students.class_id = classes.class_id
          JOIN teachers ON classes.teacher_id = teachers.teacher_id";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Student List</title>
    <style>
        /* General styling */
        body {
            background-color: #f8f9fa;
            color: #333;
        }

        .container {
            max-width: 1100px;
        }

        /* Header styling */
        .header {
            padding: 20px;
            text-align: center;
            background-color: #004d99;
            color: #fff;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        /* Table styling */
        .table {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .table th {
            background-color: #004d99;
            color: #fff;
            text-align: center;
        }

        .table td {
            vertical-align: middle;
            text-align: center;
        }

        .table-img {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 50%;
        }

        /* Hover effects */
        .table tr:hover {
            background-color: #e6f7ff;
        }

        /* Back button styling */
        .back-button {
            margin-top: 20px;
            background-color: #004d99;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .back-button:hover {
            background-color: #fff;
        }

        /* Action button styling */
        .action-btn {
            margin: 0 5px;
            padding: 5px 10px;
            border-radius: 5px;
            color: #fff;
        }

        .update-btn {
            background-color: #28a745;
        }

        .delete-btn {
            background-color: #dc3545;
        }

        /* Responsive design */
        @media (max-width: 768px) {
            .header h2 {
                font-size: 1.5rem;
            }

            .table-img {
                width: 40px;
                height: 40px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header section -->
        <div class="header mt-4">
            <h2>Student List</h2>
            <p class="mb-0">Comprehensive list of enrolled students, their classes, and assigned teachers</p>
        </div>

        <!-- Back Button -->
        <div class="text-end">
            <a href="admin_dashboard.php" class="btn back-button">Back to Dashboard</a>
        </div>

        <!-- Student Table -->
        <div class="table-responsive mt-3">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Student Number</th>
                        <th>Name</th>
                        <th>Date of Birth</th>
                        <th>Guardian Name</th>
                        <th>Guardian Contact</th>
                        <th>Date Enrolled</th>
                        <th>Class</th>
                        <th>Teacher</th>
                        <th>Photo</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['student_number']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['student_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['date_of_birth']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['guardian_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['guardian_contact']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['date_enrolled']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['class_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['teacher_name']) . "</td>";
                            echo "<td><img src='" . htmlspecialchars($row['photo']) . "' alt='Photo' class='table-img'></td>";
                            echo "<td>
                                    <a href='update_student.php?id=" . urlencode($row['student_number']) . "' class='action-btn update-btn'>Update</a>
                                    <br><br>
                                    <a href='delete_student.php?id=" . urlencode($row['student_number']) . "' class='action-btn delete-btn'>Delete</a>
                                  </td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='10' class='text-center'>No students found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
