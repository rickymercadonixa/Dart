<?php
require 'connection.php';

if (isset($_GET['id'])) {
    $user_id = $_GET['id'];

    $query = "SELECT * FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (!$user) {
        $_SESSION['message'] = "User not found.";
        $_SESSION['message_type'] = "error";
        header("Location: manage_accounts.php");
        exit();
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $delete_query = "DELETE FROM users WHERE user_id = ?";
        $delete_stmt = $conn->prepare($delete_query);
        $delete_stmt->bind_param("s", $user_id);
    
        if ($delete_stmt->execute()) {
            $_SESSION['message'] = "Account deleted successfully.";
            $_SESSION['message_type'] = "success";
            header("Location: manage_accounts.php");
            exit();
        } else {
            $_SESSION['message'] = "Error deleting account.";
            $_SESSION['message_type'] = "error";
            header("Location: manage_accounts.php");
            exit();
        }
    }
} else {
    $_SESSION['message'] = "Invalid request.";
    $_SESSION['message_type'] = "error";
    header("Location: manage_accounts.php");
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Account</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>Delete Account</h2>
    <p>Are you sure you want to delete the following account?</p>
    <ul>
        <li>Username: <?= htmlspecialchars($user['username']) ?></li>
        <li>Role: <?= htmlspecialchars($user['user_role']) ?></li>
    </ul>
    <form method="POST">
        <button type="submit" class="btn btn-danger">Confirm Deletion</button>
        <a href="manage_accounts.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>
</body>
</html>
