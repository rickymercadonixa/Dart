<?php
require 'connection.php';

$search_query = $_GET['search'] ?? '';
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';

$grades_query = "
SELECT grades.grade_id, grades.grade, grades.date_recorded, students.student_name, subjects.subject_name, teachers.teacher_name
FROM grades
JOIN students ON grades.student_id = students.student_id
JOIN subjects ON grades.subject_id = subjects.subject_id
JOIN teachers ON grades.teacher_id = teachers.teacher_id
";

$whereClauses = [];
$bindParams = [];

if (!empty($start_date) && !empty($end_date)) {
    $whereClauses[] = "grades.date_recorded BETWEEN ? AND ?";
    $bindParams[] = $start_date;
    $bindParams[] = $end_date;
} elseif (!empty($start_date)) {
    $whereClauses[] = "grades.date_recorded >= ?";
    $bindParams[] = $start_date;
} elseif (!empty($end_date)) {
    $whereClauses[] = "grades.date_recorded <= ?";
    $bindParams[] = $end_date;
}

if (count($whereClauses) > 0) {
    $grades_query .= " WHERE " . implode(" AND ", $whereClauses);
}

$stmt = $conn->prepare($grades_query);

if (!empty($bindParams)) {
    $types = str_repeat('s', count($bindParams));
    $stmt->bind_param($types, ...$bindParams);
}

$stmt->execute();
$grades_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Report: Grades</title>
<style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
        }
        .container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }
        h2 {
            color: #007bff;
        }
        .table th, .table td {
            text-align: center;
            vertical-align: middle;
        }
        .table thead {
            background-color: #007bff;
            color: white;
        }
        .table tbody tr:hover {
            background-color: #f1f1f1;
        }
        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 10px;
        }
        .btn-lg {
            width: 100%;
        }
        @media print {
    /* Hide all elements except for the table */
    body * {
        visibility: hidden;
    }
    .container, .container * {
        visibility: visible;
    }
    .container {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
    }

    /* Hide the form and the buttons */
    form, .btn {
        display: none;
    }

    /* You can also hide other elements like headers or footers here */
    h2 {
        text-align: center;
        color: black;
    }
}
</style>
</head>
<body>
<div class="col-md-4 sidebar">
            <div class="sidebar-header text-center mb-3">
                <img src="122-removebg-preview.png" alt="School Logo" class="img-fluid rounded-circle">
                <p class="mt-2">CEBUANO ELEMENTARY SCHOOL</p>
            </div>
            <nav class="nav flex-column nav-items">
                <a href="teacher_dashboard.php" class="nav_link">Dashboard</a>
                <a href="teacher_addstudents.php" class="nav_link">Add Students</a>
                <a href="teacher_addgrades.php" class="nav_link">Grades</a>
                <a href="notify.php" class="nav_link">Notification</a>
                <a href="reports.php" class="nav_link">Reports</a>
            </nav>
            <a href="teacher_logout.php" class="btn btn-danger btn-logout mt-4">Logout</a>
        </div>
        
    <div class="container mt-5">
        <h2 class="mb-4">Grades Report</h2>

        <form method="GET" class="mb-4">
            <div class="input-group">
                <a href="reports.php" class="btn btn-primary ms-2">Reset</a>
            </div>

            <div class="input-group mt-4">
                <label for="start_date" class="form-label">Start Date</label>
                <input type="date" id="start_date" name="start_date" class="form-control" value="<?php echo htmlspecialchars($start_date); ?>">
            </div>

            <div class="input-group mt-4">
                <label for="end_date" class="form-label">End Date</label>
                <input type="date" id="end_date" name="end_date" class="form-control" value="<?php echo htmlspecialchars($end_date); ?>">
            </div>

            <button type="submit" class="btn btn-primary mt-4">Generate Report</button>
        </form>

        <?php if (!empty($start_date) && !empty($end_date)) { ?>
            <table class="table table-bordered table-striped" id="gradesTable">
                <thead>
                    <tr>
                        <th>Student Name</th>
                        <th>Subject</th>
                        <th>Grade</th>
                        <th>Date Recorded</th>
                        <th>Teacher Name</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($grades_result->num_rows > 0) {
                        while ($grade = $grades_result->fetch_assoc()) { ?>
                            <tr>
                                <td><?php echo htmlspecialchars($grade['student_name']); ?></td>
                                <td><?php echo htmlspecialchars($grade['subject_name']); ?></td>
                                <td><?php echo htmlspecialchars($grade['grade']); ?></td>
                                <td><?php echo htmlspecialchars($grade['date_recorded']); ?></td>
                                <td><?php echo htmlspecialchars($grade['teacher_name']); ?></td>
                            </tr>
                        <?php }
                    } else { ?>
                        <tr>
                            <td colspan="5" class="text-center">No grades found for the selected criteria.</td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>

            <button type="button" onclick="window.print()" class="btn btn-secondary">Print Report</button>
        <?php } else { ?>
            <p class="text-center">Please select a valid date range to generate the report.</p>
        <?php } ?>

        <a href="teacher_dashboard.php" class="btn btn-primary btn-lg mt-3">Back to Dashboard</a>
    </div>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<style>
    body {
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f9;
    margin: 0;
    display: flex;
    min-height: 100vh;
}

.sidebar {
    width: 250px;
    background-color: #004d99;
    padding: 20px;
    color: white;
    position: fixed;
    height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.sidebar-header {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 30px;
}

.sidebar-header img {
    width: 90px;
    height: 90px;
    border-radius: 50%;
}

.sidebar-header p {
    font-size: 1.2rem;
    margin-top: 10px;
    text-align: center;
}

.nav-items a {
    display: block;
    text-decoration: none;
    font-size: 1.1rem;
    color: white;
    padding: 10px;
    margin-bottom: 15px;
    border-radius: 5px;
    text-align: center;
    width: 100%;
    transition: background-color 0.3s ease;
}

.nav-items a:hover {
    background-color: #003366;
}

.btn-logout {
    background-color: #e74c3c;
    color: white;
    padding: 10px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 1rem;
    transition: background-color 0.3s ease;
    text-align: center;
    width: 100%;
    margin-top: auto;
}

.btn-logout:hover {
    background-color: #c0392b;
}

.container {
    margin-left: 250px; /* Push content next to sidebar */
    padding: 40px;
    background-color: #ffffff;
    min-height: 100vh;
    box-shadow: -2px 0 5px rgba(0, 0, 0, 0.1);
}

h2 {
    color: #007bff;
    margin-bottom: 20px;
}

h3 {
    color: #333;
    margin-bottom: 20px;
}

.table th, .table td {
    text-align: center;
    vertical-align: middle;
}

.table thead {
    background-color: #007bff;
    color: white;
}

.table tbody tr:hover {
    background-color: #f1f1f1;
}

.table {
    margin-top: 20px;
    background-color: #ffffff;
    border-radius: 10px;
    overflow: hidden;
}

.form-control {
    margin-bottom: 10px;
}

.input-group {
    margin-bottom: 20px;
}

@media print {
    /* Hide all elements except for the table */
    body * {
        visibility: hidden;
    }
    .container, .container * {
        visibility: visible;
    }
    .container {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
    }

    form, .btn {
        display: none;
    }

    h2 {
        text-align: center;
        color: black;
    }
}

@media (max-width: 768px) {
    .sidebar {
        width: 100%;
        height: auto;
        position: relative;
        padding: 15px;
    }

    .container {
        margin-left: 0;
        padding: 20px;
    }

    .btn-logout {
        margin-top: 15px;
    }
}

</style>