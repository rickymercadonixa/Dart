<?php
require 'connection.php';

$student_id = $_SESSION['guardian_id'] ?? 0;

if (isset($_POST['mark_as_read'])) {
    $notification_id = $_POST['notification_id'];
    $mark_query = "UPDATE notifications SET is_read = 1 WHERE notification_id = ? AND student_id = ?";
    $mark_stmt = $conn->prepare($mark_query);
    $mark_stmt->bind_param("ii", $notification_id, $student_id);
    $mark_stmt->execute();
}

if (isset($_POST['delete'])) {
    $notification_id = $_POST['notification_id'];
    $delete_query = "DELETE FROM notifications WHERE notification_id = ? AND student_id = ?";
    $delete_stmt = $conn->prepare($delete_query);
    $delete_stmt->bind_param("ii", $notification_id, $student_id);
    $delete_stmt->execute();
}

$notifications_query = "SELECT notification_id, message, date_created, is_read FROM notifications WHERE student_id = ? ORDER BY date_created DESC";
$notifications_stmt = $conn->prepare($notifications_query);
$notifications_stmt->bind_param("i", $student_id);
$notifications_stmt->execute();
$notifications_result = $notifications_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>All Notifications</title>
</head>
<body>
    <div class="container mt-4">
        <h1>All Notifications</h1>
        <?php if ($notifications_result->num_rows > 0): ?>
            <ul class="list-group">
                <?php while ($notification = $notifications_result->fetch_assoc()): ?>
                    <li class="list-group-item <?php echo $notification['is_read'] ? 'list-group-item-light' : ''; ?>">
                        <p><?php echo htmlspecialchars($notification['message']); ?></p>
                        <small><?php echo date('F j, Y, g:i a', strtotime($notification['date_created'])); ?></small>
                        <div class="mt-2">
                            <form method="post" class="d-inline">
                                <input type="hidden" name="notification_id" value="<?php echo $notification['notification_id']; ?>">
                                <button type="submit" name="mark_as_read" class="btn btn-sm btn-success">Mark as Read</button>
                            </form>
                            <form method="post" class="d-inline">
                                <input type="hidden" name="notification_id" value="<?php echo $notification['notification_id']; ?>">
                                <button type="submit" name="delete" class="btn btn-sm btn-danger">Delete</button>
                            </form>
                        </div>
                    </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p>No notifications found.</p>
        <?php endif; ?>
        <br>
        <a href="student_inquiry.php" class="btn btn-primary">Back</a>
    </div>
    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
