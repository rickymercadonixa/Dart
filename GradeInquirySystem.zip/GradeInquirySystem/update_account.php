<?php
require 'connection.php';

if (isset($_GET['id'])) {
    $user_id = (int)$_GET['id'];

    $query = "SELECT 
              users.username,
              users.password,
              users.user_role
              FROM users
              WHERE user_id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (!$user) {
        $_SESSION['message'] = "User not found.";
        $_SESSION['message_type'] = "error";
        header("Location: manage_accounts.php");
        exit();
    }
} else {
    $_SESSION['message'] = "No user selected.";
    $_SESSION['message_type'] = "error";
    header("Location: manage_accounts.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $user_role = $_POST['user_role'];

    $update_query = "UPDATE users SET 
                        username = ?,
                        password = ?,
                        user_role = ?
                     WHERE user_id = ?";
    
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param("sssi", $username, $password, $user_role, $user_id);

    if ($update_stmt->execute()) {
        $_SESSION['message'] = "User information updated successfully.";
        $_SESSION['message_type'] = "success";
        header("Location: manage_accounts.php");
        exit();
    } else {
        $_SESSION['message'] = "Error updating user information.";
        $_SESSION['message_type'] = "error";
        header("Location: manage_accounts.php");
        exit();
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update User</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>Update User Information</h2>
    <form method="POST">
        <div class="mb-3">
            <label for="student_name" class="form-label">Username</label>
            <input type="text" class="form-control" id="student_name" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="date_of_birth" class="form-label">Password</label>
            <input type="password" class="form-control" id="date_of_birth" name="password" value="<?= htmlspecialchars($user['password']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="guardian_name" class="form-label">User role</label>
            <input type="text" class="form-control" id="guardian_name" name="user_role" value="<?= htmlspecialchars($user['user_role']) ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
        <a href="manage_accounts.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>
</body>
</html>
