<?php
require 'connection.php';

$grade_id = $_GET['id'] ?? 0;

$message = "";
$message_type = "";

if ($grade_id) {
    $stmt = $conn->prepare("
        SELECT grades.student_id, grades.subject_id, grades.grade, grades.date_recorded, grades.teacher_id,
               students.student_name, subjects.subject_name, teachers.teacher_name
        FROM grades
        JOIN students ON grades.student_id = students.student_id
        JOIN subjects ON grades.subject_id = subjects.subject_id
        JOIN teachers ON grades.teacher_id = teachers.teacher_id
        WHERE grades.grade_id = ?
    ");
    $stmt->bind_param("i", $grade_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $grade_data = $result->fetch_assoc();
}

$students_result = $conn->query("SELECT student_id, student_name FROM students");
$subjects_result = $conn->query("SELECT subject_id, subject_name FROM subjects");
$teachers_result = $conn->query("SELECT teacher_id, teacher_name FROM teachers");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = $_POST['student_id'];
    $subject_id = $_POST['subject_id'];
    $grade = $_POST['grade'];
    $date_recorded = $_POST['date_recorded'];
    $teacher_id = $_POST['teacher_id'];

    $stmt = $conn->prepare("UPDATE grades SET student_id = ?, subject_id = ?, grade = ?, date_recorded = ?, teacher_id = ? WHERE grade_id = ?");
    $stmt->bind_param("iissii", $student_id, $subject_id, $grade, $date_recorded, $teacher_id, $grade_id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Grade successfully updated.";
        $_SESSION['message_type'] = "success";
        header("Location: teacher_viewgrades.php");
        exit;
    } else {
        $message = "Error updating grade: " . $conn->error;
        $message_type = "danger";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Grade</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Update Grade</h2>
        <?php if ($grade_data): ?>
            <form method="POST" class="mt-4">
                <div class="mb-3">
                    <label for="student_id" class="form-label">Student Name</label>
                    <select id="student_id" name="student_id" class="form-control" required>
                        <?php while ($student = $students_result->fetch_assoc()): ?>
                            <option value="<?php echo $student['student_id']; ?>" <?php echo $student['student_id'] == $grade_data['student_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($student['student_name']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="subject_id" class="form-label">Subject</label>
                    <select id="subject_id" name="subject_id" class="form-control" required>
                        <?php while ($subject = $subjects_result->fetch_assoc()): ?>
                            <option value="<?php echo $subject['subject_id']; ?>" <?php echo $subject['subject_id'] == $grade_data['subject_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($subject['subject_name']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="grade" class="form-label">Grade</label>
                    <input type="text" id="grade" name="grade" value="<?php echo htmlspecialchars($grade_data['grade']); ?>" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="date_recorded" class="form-label">Date Recorded</label>
                    <input type="date" id="date_recorded" name="date_recorded" value="<?php echo htmlspecialchars($grade_data['date_recorded']); ?>" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="teacher_id" class="form-label">Teacher Name</label>
                    <select id="teacher_id" name="teacher_id" class="form-control" required>
                        <?php while ($teacher = $teachers_result->fetch_assoc()): ?>
                            <option value="<?php echo $teacher['teacher_id']; ?>" <?php echo $teacher['teacher_id'] == $grade_data['teacher_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($teacher['teacher_name']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Update Grade</button>
                <a href="teacher_viewgrades.php" class="btn btn-secondary">Cancel</a>
            </form>
        <?php else: ?>
            <div class="alert alert-danger">Grade not found.</div>
            <a href="teacher_viewgrades.php" class="btn btn-secondary">Back to Grades</a>
        <?php endif; ?>
    </div>
</body>
</html>
