<?php
require 'connection.php';

$message = '';

$totalteacher = "SELECT COUNT(teacher_id) as total_teachers from teachers";
$totalteachersresult = mysqli_query($conn, query: $totalteacher);
$totalteachers = mysqli_fetch_assoc($totalteachersresult)['total_teachers'] ?? 0;

$totalstudent = "SELECT COUNT(student_id) as total_students from students";
$totalstudentsresult = mysqli_query($conn, query: $totalstudent);
$totalstudents = mysqli_fetch_assoc($totalstudentsresult)['total_students'] ?? 0;

$sql = "SELECT teachers.*, classes.class_name FROM teachers LEFT JOIN classes ON teachers.teacher_id = classes.teacher_id";
$result = $conn->query($sql);
?>

<?php
$message = isset($_SESSION['message']) ? $_SESSION['message'] : null;
$message_type = isset($_SESSION['message_type']) ? $_SESSION['message_type'] : null;

// Clear session messages after use
unset($_SESSION['message'], $_SESSION['message_type']);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Admin Dashboard</title>
    <style>
        .officials-list {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
        }

        .official-card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin: 10px;
            width: 250px;
            text-align: center;
            transition: transform 0.2s;
        }

        .official-card img {
            border-radius: 50%;
            width: 100px;
            height: 100px;
            object-fit: cover;
        }

        .official-card h3 {
            font-size: 18px;
            margin: 10px 0;
        }

        .official-card a {
            display: inline-block;
            padding: 10px 20px;
            background-color: #f0a500;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 10px;
        }

        .official-card:hover {
            transform: translateY(-10px);
        }

        body {
            display: flex;
            min-height: 100vh;
            margin: 0;
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
        }

        /* Sidebar styling */
        .sidebar {
            width: 250px;
            background-color: #004d99;
            padding: 20px 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            color: white;
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
            gap: 10px;
        }

        .sidebar-header img {
            width: 90px;
            height: 90px;
        }

        .sidebar-header p {
            font-size: 1.2rem;
            color: #ffffff;
        }

        .nav-items a {
            display: block;
            text-decoration: none;
            font-size: 1.1rem;
            color: #ffffff;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            transition: background-color 0.3s;
            text-align: center;
        }

        .nav-items a.active,
        .nav-items a:hover {
            background-color: #003366;
        }

        .btn-logout {
            background-color: #e74c3c;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
            text-align: center;
        }

        .btn-logout:hover {
            background-color: #c0392b;
        }

        /* Main content styling */
        .main-content {
            flex-grow: 1;
            padding: 30px;
            background-color: #fff;
        }
    </style>
</head>

<body>
    <div class="sidebar">
        <div class="sidebar-header">
            <img src="122-removebg-preview.png" alt="School Logo">
            <p>CEBUANO ELEMENTARY SCHOOL</p>
        </div>
        <div class="nav-items">
            <a href="admin_dashboard.php" class="nav_link">Dashboard</a>
            <a href="teacher.php" class="nav_link">Teachers</a>
            <a href="students.php" class="nav_link">Students</a>
            <a href="student_register.php">Register Account</a>
            <a href="manage_accounts.php">Manage Accounts</a>
        </div>
        <a href="admin_logout.php" class="btn-logout">Logout</a>
    </div>

    <div class="main-content p-4 d-flex">
        <div class="content flex-grow-1">
        <div class="container mt-4">
        <!-- Display message -->
        <?php if ($message): ?>
            <div class="alert <?= $message_type === 'success' ? 'alert-success' : 'alert-danger' ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>
            <h2 class="text-left">Welcome Admin!</h2>
            <h2 class="text-left">Dashboard</h2>

            <div class="row text-center">
                <div class="col-md-6">
                    <div class="card mb-3">
                        <div class="card-body">
                            <h4 class="card-title">Teachers</h4>
                            <h3 class="card-text display-4">
                                <?php echo $totalteachers ?>
                            </h3>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card mb-3">
                        <div class="card-body">
                            <h4 class="card-title">Students</h4>
                            <h3 class="card-text display-4">
                                <?php echo $totalstudents ?>
                            </h3>
                        </div>
                    </div>
                </div>

                <div class="col-md-12">
                    <h2>Teachers Info</h2>
                    <div class="officials-list">
                        <?php
                        $count = 0;
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                if ($count < 3) {
                                    echo "
                                                <div class='official-card'>
                                            <img src='" . $row['photo'] . "' alt='Profile Picture'>
                                        <h3>" . $row['teacher_name'] . "</h3>
                                        <h3>" . $row['class_name'] . "</h3>
                                    <a href='viewteacher_profile.php?teacher_id=" . $row['teacher_id'] . "' class='btn'>View Profile</a>
                                </div>";
                                    $count++;
                                }
                            }
                        } else {
                            echo "No teachers found.";
                        }
                        ?>
                    </div>

                    <?php if ($result->num_rows > 3): ?>
                        <div class="text-center mt-3">
                            <a href="all_teachers.php" class="btn btn-primary">View All Teachers Info</a>
                        </div>
                    <?php endif; ?>


                </div>
            </div>
        </div>
</body>

</html>