<?php
require 'connection.php';

$query = "SELECT student_id, student_name FROM students";
$result = $conn->query($query);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = $_POST['student_id'];
    $message = $_POST['message'];

    $stmt = $conn->prepare("INSERT INTO notifications (student_id, message) VALUES (?, ?)");
    $stmt->bind_param("is", $student_id, $message);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Notification sent successfully!";
        $_SESSION['message_type'] = "success";
        header("Location: notify.php");
        exit();
    } else {
        $_SESSION['message'] = "Failed to send notification. Please try again.";
        $_SESSION['message_type'] = "danger";
        header("Location: notify.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Notification</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            color: #333;
            margin: 0;
        }

        .sidebar {
            background-color: #004d99;
            color: white;
            height: 100vh;
            padding: 20px;
            position: fixed;
            width: 250px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .sidebar img {
            width: 120px;
            height: 120px;
            margin-bottom: 10px;
        }

        .sidebar p {
            font-size: 1.2srem;
            margin-bottom: 30px;
            text-align: center;
        }

        .sidebar .nav-items {
            width: 100%;
        }

        .sidebar .nav_link {
            display: block;
            text-decoration: none;
            color: white;
            font-size: 1.1rem;
            padding: 10px;
            margin-bottom: 10px;
            text-align: center;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .sidebar .nav_link:hover,
        .sidebar .nav_link:focus {
            background-color: #003366;
        }

        .btn-logout {
            background-color: #e74c3c;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
            text-align: center;
        }

        .btn-logout:hover {
            background-color: #c0392b;
        }

        .content {
            margin-left: 270px;
            padding: 20px;
            background-color: #fff;
            min-height: 100vh;
        }

        .content h2 {
            font-size: 2rem;
            color: #004d99;
            margin-bottom: 20px;
        }

        .form-label {
            font-weight: bold;
        }

        .form-select,
        .form-control {
            border-radius: 5px;
            padding: 10px;
            font-size: 1rem;
        }

        button {
            background-color: #004d99;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #003366;
        }

        .alert {
            font-size: 1rem;
            margin-top: 15px;
        }
    </style>
</head>

<body>
    <div class="sidebar">
        <img src="122-removebg-preview.png" alt="School Logo">
        <p>CEBUANO ELEMENTARY SCHOOL</p>
        <nav class="nav-items">
            <a href="teacher_dashboard.php" class="nav_link">Dashboard</a>
            <a href="teacher_addstudents.php" class="nav_link">Add Students</a>
            <a href="teacher_addgrades.php" class="nav_link">Grades</a>
            <a href="notify.php" class="nav_link">Notification</a>
            <a href="reports.php" class="nav_link">Reports</a>
        </nav>
        <a href="teacher_logout.php" class="btn-logout">Logout</a>
    </div>

    <div class="content">
        <h2>Send Notification to a Specific Student</h2>
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-<?php echo $_SESSION['message_type']; ?>">
                <?php
                echo htmlspecialchars($_SESSION['message']);
                unset($_SESSION['message']);
                unset($_SESSION['message_type']);
                ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_GET['notification']) && $_GET['notification'] == 'success'): ?>
            <div class="alert alert-success">Notification sent successfully!</div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <form action="" method="POST">
            <div class="mb-3">
                <label for="student_id" class="form-label">Select Student</label>
                <select name="student_id" id="student_id" class="form-select" required>
                    <option value="" disabled selected>Select a student</option>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <option value="<?php echo $row['student_id']; ?>"><?php echo $row['student_name']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="message" class="form-label">Message</label>
                <textarea name="message" id="message" class="form-control" rows="4" required></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Send Notification</button>
        </form>
    </div>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
