<?php
require 'connection.php';

$teacher_id = isset($_GET['teacher_id']) ? $_GET['teacher_id'] : null;

if (!$teacher_id) {
    $_SESSION['message'] = "Invalid or missing teacher ID.";
    $_SESSION['message_type'] = "error";
    header("Location: admin_dashboard.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $teacher_name = $_POST['teacher_name'];
    $email = $_POST['email'];
    $contact_number = $_POST['contact_number'];
    $birthdate = $_POST['birthdate'];
    $address = $_POST['address'];
    $photo_path = $row['photo']; 

    if ($_FILES['photo']['size'] > 0) {
        $old_photo_path = $row['photo'];
        if (file_exists($old_photo_path)) {
            unlink($old_photo_path);
        }

        $photo_path = 'photo/' . $_FILES['photo']['name'];
        if ($_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            move_uploaded_file($_FILES['photo']['tmp_name'], $photo_path);
        } else {
            $_SESSION['message'] = "Error uploading new photo.";
            $_SESSION['message_type'] = "error";
            header("Location: viewteacher_profile.php?teacher_id=$teacher_id");
            exit();
        }
    }

    $sql = "UPDATE teachers 
            SET teacher_name = ?, email = ?, contact_number = ?, birthdate = ?, address = ?, photo = ? 
            WHERE teacher_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssi", $teacher_name, $email, $contact_number, $birthdate, $address, $photo_path, $teacher_id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Teacher information updated successfully.";
        $_SESSION['message_type'] = "success";
        header("Location: viewteacher_profile.php?teacher_id=$teacher_id");
        exit();
    } else {
        $_SESSION['message'] = "Error updating teacher information: " . $conn->error;
        $_SESSION['message_type'] = "error";
        header("Location: viewteacher_profile.php?teacher_id=$teacher_id");
        exit();
    }
}

$sql = "SELECT * FROM teachers WHERE teacher_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if (!$row) {
    $_SESSION['message'] = "Teacher not found.";
    $_SESSION['message_type'] = "error";
    header("Location: admin_dashboard.php");
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Update Teacher</title>
</head>
<body>
<div class="form-container">
        <h1>Update Teacher</h1>

        <form action="" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="teacher_id" value="<?php echo $row['teacher_id']; ?>">

            <div class="mb-3">
                <label for="Name" class="form-label">Name:</label>
                <input type="text" class="form-control" name="teacher_name" id="name" value="<?php echo $row['teacher_name']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Email:</label>
                <input type="email" class="form-control" name="email" id="birthdate" value="<?php echo $row['email']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="contact_number" class="form-label">Contact Number:</label>
                <input type="number" class="form-control" name="contact_number" id="birthdate" value="<?php echo $row['contact_number']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="birthdate" class="form-label">Birth Date:</label>
                <input type="date" class="form-control" name="birthdate" id="birthdate" value="<?php echo $row['birthdate']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="address" class="form-label">Address:</label>
                <input type="text" class="form-control" name="address" id="position" value="<?php echo $row['address']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="photo" class="form-label">Photo:</label>
                <input type="file" class="form-control" name="photo" id="photo">
                <img src="<?php echo $row['photo']; ?>" alt="Current Photo" class="img-fluid">
            </div>

            <button type="submit" class="btn btn-primary mb-3">Update Teacher</button>
            <a href='viewteacher_profile.php?teacher_id=<?php echo $row['teacher_id']; ?>' class='btn btn-danger col-md-12'>Cancel</a>
        </form>
    </div>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }

        .form-container {
            max-width: 600px;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-control {
            margin-bottom: 15px;
        }

        .btn-primary {
            width: 100%;
        }

        img {
            display: block;
            margin: 10px auto;
            width: 150px;
            height: auto;
            border-radius: 50%;
        }
    </style>
