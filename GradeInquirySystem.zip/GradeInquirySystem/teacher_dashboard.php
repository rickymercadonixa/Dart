<?php
require 'connection.php';

$teacher_id = $_SESSION['teacher_id'] ?? 0;
$query1 = "SELECT teacher_name FROM teachers WHERE teacher_id = ?";
$stmt = $conn->prepare($query1);
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$teacher_name_result = $stmt->get_result();
$teacher_name = $teacher_name_result->fetch_assoc()['teacher_name'] ?? 'Teacher';

// Get class IDs for the teacher
$query2 = "SELECT class_id FROM classes WHERE teacher_id = ?";
$stmt = $conn->prepare($query2);
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$result = $stmt->get_result();

$class_ids = [];
while ($class = $result->fetch_assoc()) {
    $class_ids[] = $class['class_id'];
}

if (!empty($class_ids)) {
    $class_ids_str = implode(',', $class_ids);

    // Query to get distinct students and their grades (limit to 7)
    $students_query = "
    SELECT students.student_id, students.student_number, students.student_name, MAX(grades.grade) AS grade
    FROM students
    JOIN grades ON students.student_id = grades.student_id
    WHERE students.class_id IN ($class_ids_str)
    GROUP BY students.student_id, students.student_number, students.student_name
    LIMIT 7
";
$students_result = $conn->query($students_query);

    // Query to count total distinct students based on grade_id
    $count_query = "SELECT COUNT(DISTINCT student_id) AS total_students 
                    FROM grades 
                    WHERE student_id IN (SELECT student_id FROM students WHERE class_id IN ($class_ids_str))";
    $count_result = $conn->query($count_query);
    $totalstudents = $count_result->fetch_assoc()['total_students'] ?? 0;
} else {
    $students_result = null;
    $totalstudents = 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Teacher Dashboard</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-4 sidebar">
            <div class="sidebar-header text-center mb-3">
                <img src="122-removebg-preview.png" alt="School Logo" class="img-fluid rounded-circle">
                <p class="mt-2">CEBUANO ELEMENTARY SCHOOL</p>
            </div>
            <nav class="nav flex-column nav-items">
                <a href="teacher_dashboard.php" class="nav_link">Dashboard</a>
                <a href="teacher_addstudents.php" class="nav_link">Add Students</a>
                <a href="teacher_addgrades.php" class="nav_link">Grades</a>
                <a href="notify.php" class="nav_link">Notification</a>
                <a href="reports.php" class="nav_link">Reports</a>
            </nav>
            <a href="teacher_logout.php" class="btn btn-danger btn-logout mt-4">Logout</a>
        </div>

        <div class="col-md-8 main-content">
           
        <h2>Welcome, <?php echo htmlspecialchars($teacher_name); ?>!</h2>
            <h3 class="mb-4">Your Students</h3>

            <div class="row text-center mb-4">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Total Students</h4>
                            <h3 class="card-text display-4">
                                <?php echo htmlspecialchars($totalstudents); ?>
                            </h3>
                        </div>
                    </div>
                </div>
            </div>
            <a href="teacher_viewgrades.php" class="btn btn-primary">View Grades</a>
            <br><br>

            <?php if ($students_result && $students_result->num_rows > 0): ?>
                <table class="table table-hover table-striped text-center">
                    <thead class="table-dark">
                        <tr>
                            <th>Student ID</th>
                            <th>Student Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($student = $students_result->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($student['student_number']); ?></td>
                                <td><?= htmlspecialchars($student['student_name']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="alert alert-info">No students found for your classes.</div>
            <?php endif; ?>

            <?php if ($totalstudents > 7): ?>
                <a href="teacher_viewallstudents.php" class="btn btn-primary col-md-12">View All Students</a>
            <?php endif; ?>
        </div>
    </div>
</div>
<style>
    body {
    display: flex;
    min-height: 100vh;
    margin: 0;
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f9;
}

.sidebar {
    width: 250px;
    background-color: #004d99;
    padding: 20px 10px;
    display: flex;
    flex-direction: column;
    align-items: center;
    color: white;
    height: 100vh;
    position: fixed; /* Keeps the sidebar fixed */
}

.sidebar-header {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 30px;
}

.sidebar-header img {
    width: 90px;
    height: 90px;
}

.sidebar-header p {
    font-size: 1.2rem;
    color: #ffffff;
    margin-top: 10px;
    text-align: center;
}

.nav-items a {
    display: block;
    text-decoration: none;
    font-size: 1.1rem;
    color: #ffffff;
    padding: 10px;
    margin-bottom: 15px;
    border-radius: 5px;
    transition: background-color 0.3s;
    text-align: center;
    width: 100%;
}

.nav-items a.active,
.nav-items a:hover {
    background-color: #003366;
}

.btn-logout {
            background-color: #e74c3c;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
            text-align: center;
        }

.btn-logout:hover {
    background-color: #c0392b;
}

/* Main content styling */
.main-content {
    margin-left: 250px; /* Aligns content next to sidebar */
    padding: 40px;
    flex-grow: 1;
    background-color: #ffffff;
    min-height: 100vh;
    box-shadow: -2px 0 5px rgba(0, 0, 0, 0.1);
}

.main-content h2 {
    font-size: 2rem;
    color: #333;
    margin-bottom: 20px;
}

.main-content h3 {
    font-size: 1.5rem;
    color: #555;
    margin-bottom: 20px;
}

.card {
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
    border: none;
}

.card-title {
    font-size: 1.2rem;
    font-weight: bold;
}

.table {
    margin-top: 20px;
    background-color: #ffffff;
    border-radius: 10px;
    overflow: hidden;
}

.table thead {
    background-color: #004d99;
    color: #ffffff;
}

.alert {
    margin-top: 20px;
}

.btn-primary {
    background-color: #004d99;
    border: none;
    padding: 10px 20px;
    font-size: 1rem;
    transition: background-color 0.3s;
}

.btn-primary:hover {
    background-color: #003366;
}

/* Responsive Design */
@media (max-width: 768px) {
    .sidebar {
        width: 100%;
        height: auto;
        position: relative;
        padding: 15px;
    }

    .main-content {
        margin-left: 0;
        padding: 20px;
    }

    .btn-logout {
        margin-top: 15px;
    }
}

</style>
</body>
</html>
