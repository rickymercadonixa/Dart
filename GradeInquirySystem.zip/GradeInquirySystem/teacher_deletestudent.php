<?php
require 'connection.php';

// Check if the student ID is provided and valid
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $student_id = (int)$_GET['id'];

    // Fetch the student data to confirm existence
    $query = "SELECT * FROM students WHERE student_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();

    if (!$student) {
        echo "Student not found.";
        exit();
    }

    // If the form is submitted to confirm deletion
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Delete grades related to the student first
        $delete_grades_query = "DELETE FROM grades WHERE student_id = ?";
        $delete_grades_stmt = $conn->prepare($delete_grades_query);
        $delete_grades_stmt->bind_param("s", $student_id);
        
        if ($delete_grades_stmt->execute()) {
            // After deleting grades, delete the student record
            $delete_student_query = "DELETE FROM students WHERE student_id = ?";
            $delete_student_stmt = $conn->prepare($delete_student_query);
            $delete_student_stmt->bind_param("s", $student_id);

            if ($delete_student_stmt->execute()) {
                // Redirect to the student list page
                header("Location: teacher_dashboard.php");
                exit();
            } else {
                echo "Error deleting student record.";
            }
        } else {
            echo "Error deleting grades.";
        }
    }
} else {
    echo "Invalid ID.";
    exit();
}

$conn->close();
?>
