<?php
require 'connection.php';

$search_query = $_GET['search'] ?? '';

$grades_query = "
SELECT grades.grade_id, grades.grade, grades.date_recorded, students.student_name, subjects.subject_name, teachers.teacher_name
FROM grades
JOIN students ON grades.student_id = students.student_id
JOIN subjects ON grades.subject_id = subjects.subject_id
JOIN teachers ON grades.teacher_id = teachers.teacher_id
";

if (!empty($search_query)) {
    $grades_query .= " WHERE students.student_name LIKE ? OR students.student_number LIKE ?";
}

$stmt = $conn->prepare($grades_query);

if (!empty($search_query)) {
    $search_param = "%" . $search_query . "%";
    $stmt->bind_param("ss", $search_param, $search_param);
}

$stmt->execute();
$grades_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>View Grades</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
        }
        .container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }
        h2 {
            color: #007bff;
        }
        .table th, .table td {
            text-align: center;
            vertical-align: middle;
        }
        .table thead {
            background-color: #007bff;
            color: white;
        }
        .table tbody tr:hover {
            background-color: #f1f1f1;
        }
        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 10px;
        }
        .btn-danger, .btn-success {
            margin: 0;
            padding: 6px 12px;
        }
        .btn-danger:hover, .btn-success:hover {
            opacity: 0.9;
        }
        .btn-lg {
            width: 100%;
        }
        /* Print styles */
        @media print {
            /* Hide the Action column header and cells */
            .action-buttons, th:nth-child(6), td:nth-child(6) {
                display: none;
            }
            /* Hide buttons */
            .btn {
                display: none;
            }

            .form-control{
                display: none;
            }
            h2{
                text-align: center;
                color: black;
            }
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Grades</h2>
        <?php
        if (isset($_SESSION['message'])):
            $message_type = $_SESSION['message_type'] ?? 'info';
        ?>
            <div class="alert alert-<?php echo $message_type; ?>">
                <?php 
                echo htmlspecialchars($_SESSION['message']);
                unset($_SESSION['message']);
                ?>
            </div>
        <?php endif; ?>
        <form method="GET" class="mb-4">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Search by Student Name or Number" value="<?php echo htmlspecialchars($search_query); ?>">
                <button type="submit" class="btn btn-primary">Search</button>
                <a href="teacher_viewgrades.php" class="btn btn-primary ms-2">Reset</a>
            </div>
            <button type="button" onclick="window.print()" class="btn btn-secondary mt-2">Print</button>
        </form>
        <table class="table table-bordered table-striped" id="gradesTable">
            <thead>
                <tr>
                    <th>Student Name</th>
                    <th>Subject</th>
                    <th>Grade</th>
                    <th>Date Recorded</th>
                    <th>Teacher Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($grades_result->num_rows > 0) {
                    while ($grade = $grades_result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($grade['student_name']); ?></td>
                            <td><?php echo htmlspecialchars($grade['subject_name']); ?></td>
                            <td><?php echo htmlspecialchars($grade['grade']); ?></td>
                            <td><?php echo htmlspecialchars($grade['date_recorded']); ?></td>
                            <td><?php echo htmlspecialchars($grade['teacher_name']); ?></td>
                            <td class="action-buttons">
                                <a href="update_grade.php?id=<?php echo $grade['grade_id']; ?>" class="btn btn-success btn-sm">Edit</a>
                                <a href="delete_grade.php?id=<?php echo $grade['grade_id']; ?>" class="btn btn-danger btn-sm">Delete</a>
                            </td>
                        </tr>
                    <?php }
                } else { ?>
                    <tr>
                        <td colspan="6" class="text-center">No grades found.</td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <a href="teacher_dashboard.php" class="btn btn-primary btn-lg">Back to Dashboard</a>
    </div>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function printTable() {
            const printContents = document.getElementById('gradesTable').outerHTML;
            const originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
            location.reload();
        }
    </script>
</body>
</html>
