<?php
require 'connection.php';

if (isset($_GET['id'])) {
    $grade_id = $_GET['id'];

    $query = "
        SELECT grades.grade, students.student_name 
        FROM grades 
        JOIN students ON grades.student_id = students.student_id 
        WHERE grades.grade_id = ?
    ";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $grade_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $grade_info = $result->fetch_assoc();

    if (!$grade_info) {
        echo "Grade record not found.";
        exit();
    }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $delete_query = "DELETE FROM grades WHERE grade_id = ?";
    $delete_stmt = $conn->prepare($delete_query);
    $delete_stmt->bind_param("i", $grade_id);

    if ($delete_stmt->execute()) {
        $_SESSION['message'] = "Grade record successfully deleted.";
        $_SESSION['message_type'] = "success";
        header("Location: teacher_viewgrades.php"); 
        exit();
    } else {
        $_SESSION['message'] = "Error deleting grade record.";
        $_SESSION['message_type'] = "danger";
        header("Location: teacher_viewgrades.php");
        exit();
    }
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Grade Record</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
<?php
        if (isset($_SESSION['message'])):
            $message_type = $_SESSION['message_type'] ?? 'info'; 
        ?>
            <div class="alert alert-<?php echo $message_type; ?>">
                <?php 
                echo htmlspecialchars($_SESSION['message']);
                unset($_SESSION['message']);
                ?>
            </div>
        <?php endif; ?>
    <h2>Delete Grade Record</h2>
    <p>Are you sure you want to delete the following grade record?</p>
    <ul>
        <li>Student Name: <?= htmlspecialchars($grade_info['student_name']) ?></li>
        <li>Grade: <?= htmlspecialchars($grade_info['grade']) ?></li>
    </ul>
    <form method="POST">
        <button type="submit" class="btn btn-danger">Confirm Deletion</button>
        <a href="teacher_viewgrades.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>
</body>
</html>
