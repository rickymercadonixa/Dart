<?php
require 'connection.php';

$message = "";

try {
    if (isset($_GET['id'])) {
        $student_id = $_GET['id'];

        $query = "SELECT * FROM students WHERE student_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $student_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $student = $result->fetch_assoc();

        if (!$student) {
            $message = "Student not found.";
        } else if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $delete_query1 = "DELETE FROM students WHERE student_id = ?";
            $delete_stmt1 = $conn->prepare($delete_query1);
            $delete_stmt1->bind_param("s", $student_id);

            if ($delete_stmt1->execute()) {
                $message = "Student deleted successfully.";
            } else {
                $message = "Error deleting record.";
            }
        }
    }
} catch (mysqli_sql_exception $e) {
    $message = "Delete the account first!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Student</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>Delete Student</h2>
    <?php if ($message): ?>
        <div class="alert <?= strpos($message, 'successfully') !== false ? 'alert-success' : 'alert-danger' ?>">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <?php if (!$message || strpos($message, 'successfully') === false): ?>
        <p>Are you sure you want to delete the following student?</p>
        <ul>
            <li>Student ID: <?= htmlspecialchars($student['student_id'] ?? 'N/A') ?></li>
            <li>Name: <?= htmlspecialchars($student['student_name'] ?? 'N/A') ?></li>
            <li>Guardian Name: <?= htmlspecialchars($student['guardian_name'] ?? 'N/A') ?></li>
        </ul>
        <form method="POST">
            <button type="submit" class="btn btn-danger">Confirm Deletion</button>
            <a href="viewall_students.php" class="btn btn-secondary">Cancel</a>
        </form>
    <?php else: ?>
        <a href="viewall_students.php" class="btn btn-primary mt-3">Go Back</a>
    <?php endif; ?>
</div>
</body>
</html>
