<?php
require 'connection.php';

$guardian_id = $_SESSION['guardian_id'] ?? '';

if (empty($guardian_id)) {
    header('Location: login.php');
    exit();
}

$query = "SELECT students.student_id, students.student_number, students.student_name 
          FROM students 
          JOIN users ON students.student_id = users.guardian_id
          WHERE users.guardian_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $guardian_id);
$stmt->execute();
$result = $stmt->get_result();
$student = $result->fetch_assoc();

if (!$student) {
    header('Location: login.php');
    exit();
}

$student_id = $student['student_id'];
$student_number = $student['student_number'];
$student_name = $student['student_name'];

$grades_data = null;
$response_message = "";

$notifications_query = "SELECT message, date_created FROM notifications WHERE student_id = ? ORDER BY date_created DESC";
$notifications_stmt = $conn->prepare($notifications_query);
$notifications_stmt->bind_param("i", $student_id);
$notifications_stmt->execute();
$notifications_result = $notifications_stmt->get_result();

$unread_count_query = "SELECT COUNT(*) AS unread_count FROM notifications WHERE student_id = ? AND is_read = 0";
$unread_stmt = $conn->prepare($unread_count_query);
$unread_stmt->bind_param("i", $student_id);
$unread_stmt->execute();
$unread_result = $unread_stmt->get_result();
$unread_count = $unread_result->fetch_assoc()['unread_count'] ?? 0;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $input_student_number = $_POST['student_number'];

    if ($input_student_number !== $student_number) {
        $response_message = 'This is not your student number! Grade Inquiry Canceled.';
    } else {
        $query = "
            SELECT subjects.subject_name, grades.grade, grades.description 
            FROM grades 
            JOIN subjects ON grades.subject_id = subjects.subject_id 
            WHERE grades.student_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $student_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $grades_data = [];
            while ($row = $result->fetch_assoc()) {
                $grades_data[] = [
                    'subject_name' => $row['subject_name'],
                    'grade' => $row['grade'],
                    'description' => $row['description']
                ];
            }
        } else {
            $grades_data = 'No grades available for this student.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Student Dashboard</title>
    <style>
        body {
            display: flex;
            min-height: 100vh;
            margin: 0;
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
        }

        /* Sidebar styling */
        .sidebar {
            width: 250px;
            background-color: #004d99;
            padding: 30px 10px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .sidebar img {
            width: 100%;
            margin-bottom: 20px;
        }

        .sidebar p {
            font-size: 1.2rem;
            color: #ffffff;
            margin-bottom: 30px;
            text-align: center;
        }

        .nav-items a {
            display: block;
            text-decoration: none;
            font-size: 1.1rem;
            color: #ffffff;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            text-align: left;
            transition: background-color 0.3s;
        }

        .nav-items a.active,
        .nav-items a:hover {
            background-color: #003366;
        }

        .btn-logout {
            background-color: #e74c3c;
            color: white;
            padding: 10px;
            text-align: center;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            margin-top: auto;
            transition: background-color 0.3s;
        }

        .btn-logout:hover {
            background-color: #c0392b;
        }

        /* Main content styling */
        .main-content {
            flex-grow: 1;
            padding: 30px;
            background-color: #fff;
        }

        .main-content h1 {
            font-size: 2rem;
            color: #333;
            margin-bottom: 20px;
        }

        .main-content p {
            font-size: 1.1rem;
            color: #555;
            line-height: 1.6;
        }

        .table {
            margin-top: 30px;
        }
    </style>
</head>

<body>
    <div class="sidebar">
        <img src="122-removebg-preview.png" alt="School Logo">
        <p>CEBUANO ELEMENTARY SCHOOL</p>
        <div class="nav-items">
            <a href="student_inquiry.php" class="nav_link">Inquiry Form</a>
        </div>
        <a href="student_logout.php" class="btn-logout">Logout</a>
    </div>

    <div class="main-content">
        <h1>Welcome <?php echo htmlspecialchars($student_name); ?>!</h1>
        <div class="dropdown mb-4" style="float: right;">
            <button class="btn btn-secondary" type="button" id="notificationDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                Notifications
                <?php if ($unread_count > 0): ?>
                    <span class="badge bg-danger"><?php echo $unread_count; ?></span>
                <?php endif; ?>
            </button>
            <ul class="dropdown-menu" aria-labelledby="notificationDropdown">
                <?php
                $count = 0;
                if ($notifications_result->num_rows > 0) {
                    while ($notification = $notifications_result->fetch_assoc()) {
                        if ($count >= 3) break;
                ?>
                        <li class="dropdown-item">
                            <p class="mb-1"><?php echo htmlspecialchars($notification['message']); ?></p>
                            <small class="text-muted"><?php echo date('F j, Y, g:i a', strtotime($notification['date_created'])); ?></small>
                        </li>
                        <div class="dropdown-divider">
                        </div>
                <?php
                        $count++;
                    }
                } else {
                    echo '<li class="dropdown-item">No new notifications.</li>';
                }
                ?>
                <?php if ($notifications_result->num_rows > 3) {
                } ?>
                <li class="dropdown-item text-center">
                <small><i><a href="all_notification.php" class="notification-link">View all notifications</a></i></small>
                </li>
            </ul>
        </div>

        <form action="" method="POST">
            <h1 class="form-title">Grade Inquiry Form</h1>
            <div class="form-group">
                <label for="student_number">Student Number:</label>
                <input type="number" id="student_number" name="student_number" class="form-control" placeholder="Enter your Student Number" required>
            </div>
            <div class="form-group">
                <button type="submit" class="btn-submit">Inquire Grades</button>
            </div>
        </form>

        <?php if (!empty($response_message)): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo htmlspecialchars($response_message); ?>
    </div>
<?php endif; ?>

        <?php if ($grades_data !== null): ?>
            <?php if (is_array($grades_data)): ?>
                <table class="table table-bordered text-center" id="grades-table">
                    <thead>
                        <tr>
                            <th>Subject</th>
                            <th>Grade</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($grades_data as $data): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($data['subject_name']); ?></td>
                                <td><?php echo htmlspecialchars($data['grade']); ?></td>
                                <td><?php echo htmlspecialchars($data['description']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <button class="btn btn-primary mt-3" onclick="printTable()">Print</button>
                </table>
            <?php else: ?>
                <h2><?php echo htmlspecialchars($grades_data); ?></h2>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
    <script>
function printTable() {
    // Get the table element
    var table = document.getElementById('grades-table').outerHTML;

    // Open a new window for printing
    var printWindow = window.open('', '', 'width=800,height=600');

    // Write the table HTML into the new window
    printWindow.document.write(`
        <html>
            <head>
                <title>Print Grades Table</title>
                <style>
                    table {
                        width: 100%;
                        border-collapse: collapse;
                        margin: 20px 0;
                    }
                    table, th, td {
                        border: 1px solid black;
                    }
                    th, td {
                        padding: 8px;
                        text-align: center;
                    }
                </style>
            </head>
            <body>
                ${table}
            </body>
        </html>
    `);

    // Close the document to finish loading
    printWindow.document.close();

    // Trigger the print dialog
    printWindow.print();

    // Optionally close the print window
    printWindow.close();
}

</script>

</body>
</html>
<style>
    /* Form styling */
    .form-title {
        font-size: 2rem;
        color: #004d99;
        margin-bottom: 20px;
        text-align: center;
        font-weight: bold;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        font-size: 1.1rem;
        color: #333;
        display: block;
        margin-bottom: 8px;
    }

    .form-group input {
        width: 100%;
        padding: 10px;
        font-size: 1rem;
        border: 2px solid #ccc;
        border-radius: 5px;
        box-sizing: border-box;
        margin-top: 5px;
        transition: border-color 0.3s;
    }

    .form-group input:focus {
        border-color: #004d99;
        outline: none;
    }

    .btn-submit {
        background-color: #004d99;
        color: white;
        font-size: 1.2rem;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        width: 100%;
        transition: background-color 0.3s;
    }

    .btn-submit:hover {
        background-color: #003366;
    }
</style>