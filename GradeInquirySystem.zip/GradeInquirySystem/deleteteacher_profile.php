<?php
require 'connection.php';

$teacher_id = isset($_GET['teacher_id']) ? (int)$_GET['teacher_id'] : null;

if (!$teacher_id) {
    $_SESSION['message'] = "Invalid or missing teacher ID.";
    $_SESSION['message_type'] = "error";
    header("Location: admin_dashboard.php");
    exit();
}

$conn->begin_transaction();

try {
    $sqlClasses = "DELETE FROM classes WHERE teacher_id = ?";
    $stmtClasses = $conn->prepare($sqlClasses);
    $stmtClasses->bind_param("i", $teacher_id);
    $stmtClasses->execute();
    $stmtClasses->close();

    $sqlTeacher = "DELETE FROM teachers WHERE teacher_id = ?";
    $stmtTeacher = $conn->prepare($sqlTeacher);
    $stmtTeacher->bind_param("i", $teacher_id);
    $stmtTeacher->execute();
    $stmtTeacher->close();

    $conn->commit();

    $_SESSION['message'] = "Teacher and related records deleted successfully.";
    $_SESSION['message_type'] = "success";
    header("Location: admin_dashboard.php");
    exit();
} catch (Exception $e) {

    $conn->rollback();

    $_SESSION['message'] = "Delete Account First! ";
    $_SESSION['message_type'] = "error";
    header("Location: admin_dashboard.php");
    exit();
}
?>