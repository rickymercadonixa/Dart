<?php
require 'connection.php';

$query = "
    SELECT classes.class_name, subjects.subject_name
    FROM classes
    JOIN subjects ON classes.subject_id = subjects.subject_id
";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>View Classes and Subjects</title>
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Classes and Subjects</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Class Name</th>
                    <th>Subject Name</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['class_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['subject_name']); ?></td>
                        </tr>
                    <?php }
                } else { ?>
                    <tr>
                        <td colspan="2">No classes or subjects found.</td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
