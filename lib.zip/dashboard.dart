import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:flutter/material.dart';
import 'activity_one.dart';
import 'loginscreen.dart';

class Dashboard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: DashboardHome(),
    );
  }
}

class DashboardHome extends StatefulWidget {
  @override
  State<DashboardHome> createState() => _DashboardHomeState();
}

class _DashboardHomeState extends State<DashboardHome> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 40.0,
              backgroundImage: AssetImage('assets/kei.jpg'),
            ),
            Text(
              "Menu",
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text("Logout", style: TextStyle(color: Colors.white)),
              onTap: () {
                // Show Logout Confirmation
                AwesomeDialog(
                  context: context,
                  dialogType: DialogType.question,
                  title: 'Logout',
                  desc: "Are you sure you want to logout?",
                  btnOkOnPress: () {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (BuildContext context) => LoginScreenHome()));
                  },
                  btnOkText: 'Yes',
                  btnCancelText: 'No',
                  btnCancelOnPress: () {},
                ).show();
              },
            ),
            ListTile(
              leading: Icon(Icons.contacts),
              title: Text("List of Users", style: TextStyle(color: Colors.white)),
              onTap: () {
                // Navigate to List of Users (Add functionality here)
                print("Navigate to List of Users");
              },
            ),
            ListTile(
              leading: Icon(Icons.settings),
              title: Text("Album", style: TextStyle(color: Colors.white)),
              onTap: () {
                // Navigate to Album (Add functionality here)
                print("Navigate to Album");
              },
            ),
          ],
        ),
        backgroundColor: Colors.deepPurpleAccent,
      ),
      appBar: AppBar(
        title: Text("Dashboard"),
      ),
      bottomNavigationBar: BottomNavigationBar(items: [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
        BottomNavigationBarItem(icon: Icon(Icons.contacts), label: 'Contacts'),
        BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'Settings'),
      ]),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 90.0,
              backgroundImage: AssetImage('assets/kei.jpg'),
            ),
            Text(
              "Ricky B. Mercado",
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            Text(
              "Bachelor of Science and Information Technology",
              style: TextStyle(color: Colors.white),
            ),
            SizedBox(
              height: 30,
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (BuildContext context) => ActivityOne()),
                );
              },
              child: Text('To Activity One'),
            ),
          ],
        ),
      ),
      backgroundColor: Colors.deepPurple,
    );
  }
}
