import 'package:flutter/material.dart';

import 'dashboard.dart';

class ActivityOne extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false, home: ActivityOneHome());
  }
}

class ActivityOneHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

        backgroundColor: Colors. deepPurpleAccent,
        body: Center(
        child: Card(
        elevation: 50,
        shadowColor: Colors.black,
        color: Colors.deepPurpleAccent[100],
        child: SizedBox(
        width: 400,
        height: 500,
        child: Padding(
        padding: const EdgeInsets.all(20.0),
            child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 90.0,
              backgroundImage: AssetImage('assets/kei.jpg'),
            ),
            Center(
              child: Text('Ricky B. Mercado', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold),),
            ),
            ElevatedButton.icon(
                onPressed: (){
                  Navigator.of(context).push(MaterialPageRoute(builder:(BuildContext context)=> Dashboard()));
                },
              icon: Icon(Icons.arrow_back),
              label: Text("Back to Dashboard"),
            ),
          ],
        )
        ),
        ),
        ),
        ),
        appBar: AppBar(title: Center(
          child: Text("Activity One"),
        )),
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Hello World")));
          },
          child: Icon(Icons.add),
        ),
        );

  }
}



