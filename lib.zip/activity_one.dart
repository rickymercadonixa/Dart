import 'package:flutter/material.dart';

import 'dashboard.dart';

class ActivityOne extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false, home: ActivityOneHome());
  }
}

class ActivityOneHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

        backgroundColor: Colors. deepPurpleAccent,
        body: Center(child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Ricky B. Mercado', style: TextStyle(color: Colors.white, fontSize: 50, fontWeight: FontWeight.bold),),
            ElevatedButton(
                onPressed: (){
                  Navigator.of(context).push(MaterialPageRoute(builder:(BuildContext context)=> Dashboard()));
                },
                child: Text('To Dashboard')
            ),
          ],
        )),
        appBar: AppBar(title: Text('ActivityOne')),
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Hello World")));
          },
          child: Icon(Icons.add),
        ));
  }
}



