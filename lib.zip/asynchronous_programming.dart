
class AsyncProgram{
  Future<List<Map<String,dynamic>>> getUsers() async{
    var user = [{'id':1, 'name':'John'},
      {'id':2, 'name':'Jane'}];
    return user;
  }

}
